<?php
require __DIR__.'/vendor/autoload.php';
//include('html2pdf.php');
use Spipu\Html2Pdf\Html2Pdf;


$findallinnvoice = json_decode($_POST['findallinnvoice']);
$findpid = json_decode($_POST['findpid'],true);
$findtotalpaidamt = $_POST['findtotalpaidamt'];

foreach($findpid as $k=>$v){
    if($k == "patient_name"){$name = $v;}
    if($k == "unique_pid"){$patientid = $v;}
    if($k == "email"){$email = $v;}
    if($k == "mobile_number"){$mobile_number = $v;}
    if($k == "gender"){if($v == "m"){$gender = "Male";}if($v == "f"){$gender = "Female";}}
    if($k == "dob"){if($v == ""){$dob = "-";}else{$dob = date('Y') - date('Y',strtotime($v));}}
}
foreach($findallinnvoice as $k=>$v){$invno = $v->invoice_number;}
$datenow = date("d M Y");
// print_r($findpid);
// exit();
// $findpid = $_POST['findpid'];
// print_r($findpid->patient_name);


$output = '<page><div style="position:absolute;left:50%;margin-left:-297px;top:10px;width:595px;height:842px;border-style:outset;overflow:hidden;font-size:12px;">
        
        <div style="position: absolute;left: 160px;top:0;"><img src="./printheader.png" style="height:98px;" /></div>
        <div style="position: absolute;left: 60px;top:88%;"><img src="./printfooter.png" style="height:40px;width:88%;" /></div>
        
        <div style="position:relative;top:98px;">
            <div style="position:absolute; left:40px;" >
                <p>Patient Name : <b>'.$name.' '.$gender.' ('.$dob.') </b> <br>Patient ID : <b>'.$patientid.'</b></p>
            </div>
            <div style="position:absolute; left:320px" >
                <p>Mob No. : <b>'.$mobile_number.'</b><br>Email : <b>'.$email.'</b></p>
            </div>
        </div>
                
        
        
        <hr style="position:absolute; top: 143px; left: 0; width: 100%;color:#c7c8c9; ">
        
        
        <div style="position:absolute; top:145px;width:100%;">
            <div style="position:absolute; left:40px;top:-8px; ">
                <p style="color: #198754;font-size:18px;">Invoices</p>
            </div>
            <div style="position:absolute; left:200px" >
                <p>Date : <b>'.$datenow.'</b></p>
            </div>
            <div style="position:absolute; left:380px" >
                <p>Invoice Number : <b>'.$invno.'</b></p>
            </div>
        </div>
        
        <hr style="position:absolute; top: 178px; left: 0; width: 100%;color:#c7c8c9; ">
        
        <div style="position:absolute; top:185px;width:100%;">
            <div style="position:absolute; left:40px;" >
                <p><b>Treatment& Products</b></p>
            </div>
            <div style="position:absolute; left:200px" >
                <p><b>Unit Cost</b></p>
            </div>
            <div style="position:absolute; left:330px" >
                <p><b>Qty</b></p>
            </div>
            <div style="position:absolute; left:380px" >
                <p><b>Concession</b></p>
            </div>
            <div style="position:absolute; left:460px" >
                <p><b>Total Cost INR </b></p>
            </div>
        </div>
        
        ';
        $totalamtmain = 0;
        $paidamt = $findtotalpaidamt;
        $top = 200;
        $concession = 0;
        foreach($findallinnvoice as $k=>$v){
            $totalamt = "0";
            if($v->discount != 0){
                if($v->discount_type == "NUMBER"){
                    $totalamt = ($v->unit_cost * $v->quantity) - ($v->discount);
                    $concession = $v->discount." INR";
                } else if($v->discount_type == "PERCENT"){
                    $totalamt = ($v->unit_cost * $v->quantity) - (($v->unit_cost * $v->quantity) * ($v->discount/100));
                    $concession = $v->discount." %";
                }
            }else{
                $totalamt = ($v->unit_cost * $v->quantity);
            }
            $output .= '
            <div style="position:absolute; top:'.$top.'px;width:100%;">
                <div style="position:absolute; left:40px;" >
                    <p>'.$v->treatment_name.'</p>
                </div>
                <div style="position:absolute; left:210px" >
                    <p>'.$v->unit_cost.'</p>
                </div>
                <div style="position:absolute; left:340px" >
                    <p>'.$v->quantity.' </p>
                </div>
                <div style="position:absolute; left:390px" >
                    <p>'.$concession.'</p>
                </div>
                <div style="position:absolute; left:470px" >
                    <p>'.$totalamt.'</p>
                </div>
            </div>
            ';
            $top = $top + 20;
            $totalamtmain = $totalamt + $totalamtmain;
        }
        $remamt = $totalamtmain - $paidamt;
    $output .= '
        
        <hr style="position:absolute; top: '.($top + 10).'px; left: 0; width: 100%;color:#c7c8c9; ">
        <div style="position:absolute; top:'.($top + 20).'px;width:100%;">
            <div style="position:absolute; left:420px" >
                <p style="margin:0;">Total Amount: <b>'.$totalamtmain.'</b></p>
                <p style="margin:0;">Paid Amount: <b>'.$paidamt.'</b></p>
                <p style="margin:0;">Remaining Amount: <b>'.$remamt.'</b></p>
            </div>
        </div>
        
    </div></page>';
// echo $output;exit();
// exit();
$html = ob_get_contents();
        ob_end_clean();

//$html2pdf = new Html2Pdf();
$html2pdf = new Html2Pdf('P', 'A5', 'en', true, 'UTF-8', array(0, 0, 0, 0));
$html2pdf->setTestTdInOnePage(false);
     // $html2pdf->pdf->SetDisplayMode('fullpage');
     //$html2pdf->WriteHTML($html22);
	
$html2pdf->writeHTML($output);
$filename = "Invoice_".$invno;
$file = "/../uploads/invoicefiles/".$filename.".pdf";
$html2pdf->Output(__DIR__.$file,'F');
echo $filename.".pdf";
// $html2pdf->Output(__DIR__ .$file,'F');
// return $n;

// $html2pdf->output('pakainfo.pdf'); 
// $html2pdf->output();



?>