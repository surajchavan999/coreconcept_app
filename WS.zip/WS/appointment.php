<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->fetchdept))
        {
            $finddept = find("all","department","*","where 1",array());

            $findpatient = find("all","patient","*","where 1",array());
            $findpatientarr = array();
            // foreach($findpatient as $key=>$val){
            //     $value = "";
            //     $label = "";
            //     // $temp = { value : "$val['patient_id']", label : "$val['patient_name']" };
            //     // array_push($findpatientarr, { 'value' : $val['patient_id'], 'label' : $val['patient_name'] } );
            // }

            $result = array("Status"=>"ok","finddept"=>$finddept,"findpatient"=>$findpatient);
	        echo json_encode($result);
        }

        if(isset($postdata->fetchpatientdetail))
        {
            $pid = $postdata->pid;

            $findpatientdetails = find("first","patient","*","where patient_id = '".$pid."' ",array());

            $result = array("Status"=>"ok","findpatientdetails"=>$findpatientdetails);
	        echo json_encode($result);
        }

        if(isset($postdata->add_appoinment))
            {
                function findinnvoiceno(){
                    $ino = "INV".rand(1,9999);
                    $findinvono = find("first","invoices","*","where invoice_number = '".$ino."' ",array());
                    if($findinvono){
                        findinnvoiceno();
                    } else {
                        return $ino;
                    }
                }
    
                $user = $postdata->user;
                if($user === "Patient"){$status = "P";}else{$status = "A";}
                $type = $postdata->type;
                $pid = $postdata->pid;
                $department = $postdata->department;
                $category = isset($postdata->category) ? $postdata->category : "";
                $schdate = $postdata->schdate;
                $apptime = (isset($postdata->apptime)) ? $postdata->apptime : "";
                $fortime = (isset($postdata->fortime)) ? $postdata->fortime : "15" ;
                $notice = (isset($postdata->notice)) ? $postdata->notice : "";
                $availableslot = $postdata->availableslot;
                $starttime = date("H:i",strtotime($availableslot));
                $endtime = date("H:i",strtotime('+'.$fortime.' minutes',strtotime($starttime)));
                // $starttime = explode("-",$availableslot)[0];
                // $endtime = explode("-",$availableslot)[1];
                // print_r($starttime);
                // print_r($endtime);
                $fees = (isset($postdata->fees)) ? $postdata->fees : "";
                $pprocedure = (isset($postdata->pprocedure)) ? $postdata->pprocedure : "";
                $doctor_id = (isset($postdata->doctor_id)) ? $postdata->doctor_id : "0";
    
                // $endtime = date("H:i",strtotime('+'.$fortime.' minutes',strtotime($apptime)));
    
                $fields = "dept_id,doc_id,schedule_date,schedule_time,start_time,end_time,fortime,patient_id,mode,remarks,category,fees,planned_procedure,status,created_date";
                $values = ":dept_id,:doc_id,:schedule_date,:schedule_time,:start_time,:end_time,:fortime,:patient_id,:mode,:remarks,:category,:fees,:planned_procedure,:status,:created_date";
                $exe = array(
                    ":dept_id"=>$department,
                    ":doc_id"=>$doctor_id,
                    ":schedule_date"=>$schdate,
                    ":schedule_time"=>$starttime,
                    ":start_time"=>$starttime,
                    ":end_time"=>$endtime,
                    ":fortime"=> $fortime,
                    ":patient_id"=>$pid,
                    ":mode"=>$type,
                    ":remarks"=>$notice,
                    ":category"=>$category,
                    ":fees"=>$fees,
                    ":planned_procedure"=>$pprocedure,
                    ":status"=>$status,
                    ":created_date"=>date("Y-m-d H:i:s"),
                );
                // print_r($exe);
    
                $saveappoitment = save("appointment",$fields,$values,$exe);
    
                if($saveappoitment){
                    
                    savenotification("0",$pid,"","patient","Appointment Booked","Your Appointment Book for ".$starttime." To ".$endtime." on ".$schdate); //notification for patient
                    savenotification("0",$doctor_id,"","doctor","Appointment Booked","New Appointment on ".$schdate." from ".$starttime." to ".$endtime); //notification for doctor
                    
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL,"https://clinic.coreconcept.in/ws/PHPMailer/send_appointment_mail.php");
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS,"pid=$pid&doctor_id=$doctor_id&schdate=$schdate&starttime=$starttime&endtime=$endtime&department=$department&saveappoitment=$saveappoitment");
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $server_output = curl_exec($ch);
                    curl_close ($ch);
    
                    
                    $findalreadyapp = find("first","invoices","*","where patient_id = '$pid' AND dept_id = '$department' ",array());
    
                    $fields = "invoice_number,appointment_id,patient_id,doctor_id,treatment_name,dept_id,unit_cost,quantity,discount,discount_type,cancelled,created_at";
                    $values = ":invoice_number,:appointment_id,:patient_id,:doctor_id,:treatment_name,:dept_id,:unit_cost,:quantity,:discount,:discount_type,:cancelled,:created_at";
                    if($findalreadyapp){
                        $findfees = find("first","doctor","*","where doctor_id = '".$doctor_id."' ",array());
                        $exein = array(
                                ":invoice_number" => findinnvoiceno(),
                                ":appointment_id" => $saveappoitment,
                                ":patient_id" => $pid,
                                ":doctor_id" => $doctor_id,
                                ":treatment_name" => "Re-Appointment",
                                ":dept_id" => $department,
                                ":unit_cost" => $findfees['consultaionfeesother'],
                                ":quantity" => "1",
                                ":discount" => "0",
                                ":discount_type" => "NUMBER",
                                ":cancelled" => 0,
                                ":created_at" => date("Y-m-d H:i:s")
                            );
                    } else{
                        $findfees = find("first","doctor","*","where doctor_id = '".$doctor_id."' ",array());
                        $exein = array(
                                ":invoice_number" => findinnvoiceno(),
                                ":appointment_id" => $saveappoitment,
                                ":patient_id" => $pid,
                                ":doctor_id" => $doctor_id,
                                ":treatment_name" => "First Appointment",
                                ":dept_id" => $department,
                                ":unit_cost" => $findfees['consultaionfeesfirst'],
                                ":quantity" => "1",
                                ":discount" => "0",
                                ":discount_type" => "0",
                                ":cancelled" => 0,
                                ":created_at" => date("Y-m-d H:i:s")
                            );
                    }
                    $saveinvoice = save("invoices",$fields,$values,$exein);
                }
    
                $result = array("Status"=>"ok","saveappoitment"=>$saveappoitment);
    	        echo json_encode($result);
            }

        if(isset($postdata->fetchdocdetails))
        {
            $deptid = $postdata->deptid;

            $finddoctor = find("all","doctor","*","where dept_id = '".$deptid."' ",array());

            $result = array("Status"=>"ok","finddoctor"=>$finddoctor);
	        echo json_encode($result);
        }

        if(isset($postdata->fetchappdata))
        {
            $user = $postdata->user;
            $user_id = $postdata->user_id;
            
            $findalldept = find("all","department","*","where 1",array());

            $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id inner join patient on patient.patient_id=appointment.patient_id";
            if($user == "Doctor")
            {
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus","where appointment.doc_id = '".$user_id."' ORDER BY appointment.schedule_date DESC ",array());
            }
            if($user == "Patient")
            {
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus","where appointment.patient_id = '".$user_id."' ORDER BY appointment.schedule_date DESC",array());
            }
            if($user == "Staff")
            {
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus","where 1 ORDER BY appointment.schedule_date DESC",array());
            }
            if($user == "Admin")
            {
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus","where 1 ORDER BY appointment.schedule_date DESC",array());
            }

            $result = array("Status"=>"ok","findallappoitment"=>$findallappoitment,"findalldept"=>$findalldept);
	        echo json_encode($result);
        }
        
        
        if(isset($postdata->filterappdata))
        {
            $user = $postdata->user;
            $user_id = $postdata->user_id;
            $appdate = $postdata->appdate;
            $appdept = $postdata->appdept;
            // print_r($appdate." = ".$appdept);
            $findalldept = find("all","department","*","where 1",array());

            $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id inner join patient on patient.patient_id=appointment.patient_id";
            if($user == "Doctor")
            {
                $where = "where appointment.doc_id = '".$user_id."' ";
                if(isset($appdate) || $appdate != ""){ $where .= " and appointment.schedule_date = '".$appdate."' "; }
                if(isset($appdept) || $appdept != ""){ $where .= " and appointment.dept_id = '".$appdept."' "; }
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus",$where." ORDER BY appointment.schedule_date DESC ",array());
            }
            if($user == "Patient")
            {
                $where = "where appointment.patient_id = '".$user_id."' ";
                if(isset($appdate) || $appdate != ""){ $where .= " and appointment.schedule_date = '".$appdate."' "; }
                if(isset($appdept) || $appdept != ""){ $where .= " and appointment.dept_id = '".$appdept."' "; }
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus",$where." ORDER BY appointment.schedule_date DESC",array());
            }
            if($user == "Staff")
            {
                $where = "where 1 ";
                if(isset($appdate) || $appdate != ""){ $where .= " and appointment.schedule_date = '".$appdate."' "; }
                if(isset($appdept) || $appdept != ""){ $where .= " and appointment.dept_id = '".$appdept."' "; }
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus",$where." ORDER BY appointment.schedule_date DESC",array());
            }
            if($user == "Admin")
            {
                $where = "where 1 ";
                if(isset($appdate) || $appdate != ""){ $where .= " and appointment.schedule_date = '".$appdate."' "; }
                if(isset($appdept) && $appdept != ""){ $where .= " and appointment.dept_id = '".$appdept."' "; }
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus",$where." ORDER BY appointment.schedule_date DESC",array());
            }

            $result = array("Status"=>"ok","findallappoitment"=>$findallappoitment,"findalldept"=>$findalldept);
	        echo json_encode($result);
        }

        if(isset($postdata->reschduleappoitment))
        {
            $schedule_date = $postdata->schedule_date;
            $availableslot = $postdata->availableslot;
            $appointment_id = $postdata->appointment_id;
            // $starttime = explode("-",$availableslot)[0];
            // $endtime = explode("-",$availableslot)[1];
            $starttime = $availableslot;
            $endtime = date("H:i",strtotime('+'.$fortime.' minutes',strtotime($availableslot)));;
            
            $findappdetails = find("first","appointment","*","where appointment_id = '".$appointment_id."' ",array());

            $setvalue = "schedule_date=:schedule_date,schedule_time=:schedule_time,start_time=:start_time,end_time=:end_time";
            $wherecon = "where appointment_id = '".$appointment_id."' ";
            $exe = array(
                        ":schedule_date" => $schedule_date,
                        ":schedule_time" => $starttime,
                        ":start_time" => $starttime,
                        ":end_time" => $endtime,
                    );
            $updateapp = update("appointment",$setvalue,$wherecon,$exe);
            
            if($updateapp){
                savenotification("0",$findappdetails['patient_id'],"","patient","Appointment Re-Scheduled","Your Appointment Re-Scheduled for ".$starttime." To ".$endtime." on ".$schedule_date); //notification for patient
                savenotification("0",$findappdetails['doc_id'],"","doctor","Appointment Re-Scheduled","New Appointment Re-Scheduled on ".$schedule_date." from ".$starttime." to ".$endtime); //notification for doctor
                
                $appointment_id = $appointment_id;
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL,"https://clinic.coreconcept.in/ws/PHPMailer/send_appointment_cancel_mail.php");
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS,"appointment_id=$appointment_id");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $server_output = curl_exec($ch);
                curl_close ($ch);
            }
            
            $result = array("Status"=>"ok","updateapp"=>$updateapp);
	        echo json_encode($result);
        }

        if(isset($postdata->changestatus))
        {
            $appointment_id = $postdata->appointment_id;
            $status = $postdata->status;

            $setvalue = "status=:status";
            $wherecon = "where appointment_id = '".$appointment_id."' ";
            $execon = array(":status"=>$status);
            $updatestatus = update("appointment",$setvalue,$wherecon,$execon);
            
            if($status == "C"){
                if($updatestatus){
                    $findappdetails = find("first","appointment","*","where appointment_id = '".$appointment_id."' ",array());
                    savenotification("0",$findappdetails['patient_id'],"","patient","Appointment Canceled","Appointment Canceled of ".$starttime." To ".$endtime." on ".$schedule_date); //notification for patient
                    savenotification("0",$findappdetails['doc_id'],"","doctor","Appointment Canceled","Appointment Canceled of ".$schedule_date." at ".$starttime." to ".$endtime);//notification for doctor
                }
            }

            $result = array("Status"=>"ok","updatestatus"=>$updatestatus);
	        echo json_encode($result);
        }

        if(isset($postdata->fetchpappdata))
        {
            $puid = $postdata->puid;

            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());

            $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id";
            $findallpapp = find('all',$tableappoit,'*, appointment.status as astatus',"where patient_id = '".$findpid['patient_id']."' ORDER BY appointment.schedule_date DESC ",array());

            $result = array("Status"=>"ok","findallpapp"=>$findallpapp);
	        echo json_encode($result);
        }
        
        if(isset($postdata->checkdocsch))
        {
            $doctor_id = $postdata->doctor_id;
            $selectdate = $postdata->selectdate;
            $status = "";
            $weekday = date("l",strtotime($selectdate));
            $finddocshecdule = find("first","doc_schedule","*","where doctor_id = '".$doctor_id."' and day = '".$weekday."' ",array());
            $fromtoarr = array();
            if($finddocshecdule){
                $timearr = array();
                $findapptaken = find("all","appointment","*","where schedule_date = '".$selectdate."' and doc_id = '".$doctor_id."' and status != 'C' ",array());
                foreach($findapptaken as $kk=>$vv){ array_push($timearr,$vv['start_time']."-".$vv['end_time']); }
                $from = new DateTime($finddocshecdule['in_time']);
                $to = new DateTime($finddocshecdule['out_time']);
                while ($from < $to) {
                    if($selectdate == date("Y-m-d")){
                        // $fromt = $from->format('h:i A');
                        // $from->add(new DateInterval('PT20M'));
                        // $tot = $from->format('h:i A');
                        // if($fromt > date("h:i A")){
                        //     if(in_array($fromt."-".$tot,$timearr)){}else{
                        //         array_push($fromtoarr,$fromt."-".$tot);
                        //     }
                        // }
                        $fromt = $from->format('h:i A');
                        $from->add(new DateInterval('PT60M'));
                        $tot = $from->format('h:i A');
                        if($fromt > date("h:i A")){
                            if(in_array($fromt,$timearr)){}else{
                                array_push($fromtoarr,$fromt);
                            }
                        }
                    } else {
                        // $fromt = $from->format('h:i A');
                        // $from->add(new DateInterval('PT20M'));
                        // $tot = $from->format('h:i A');
                        // if(in_array($fromt."-".$tot,$timearr)){}else{
                        //     array_push($fromtoarr,$fromt."-".$tot);
                        // }
                        $fromt = $from->format('h:i A');
                        $from->add(new DateInterval('PT60M'));
                        $tot = $from->format('h:i A');
                        if(in_array($fromt,$timearr)){}else{
                            array_push($fromtoarr,$fromt);
                        }
                    }
                }
            } else {
                $status = "Doctor is Not available that day.";
            }
            
            $result = array("Status"=>"ok","status"=>$status,"finddocshecdule"=>$finddocshecdule,"fromtoarr"=>$fromtoarr);
	        echo json_encode($result);
        }
    }
?>