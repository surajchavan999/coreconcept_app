<?php
require __DIR__.'/vendor/autoload.php';
//include('html2pdf.php');
use Spipu\Html2Pdf\Html2Pdf;
$html2pdf = new Html2Pdf(); 
//$html2pdf = new HTML2PDF('P', 'A4', 'en');
// $html2pdf->setTestTdInOnePage(false); 
// $html = file_get_contents('index_1.html'); 
// $html2pdf->writeHTML($html);
// $html2pdf->output();


$html = '<page> <div style="position:absolute;left:50%;margin-left:-297px;top:0px;width:595px;height:842px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="af67bbc4-0af7-11ec-a980-0cc47a792c0a_id_af67bbc4-0af7-11ec-a980-0cc47a792c0a_files/background1.jpg" width=595 height=842></div>
<div style="position:absolute;left:133.22px;top:158.38px" class="cls_004"><span class="cls_004">BUSINESS PROPOSAL</span></div>
<div style="position:absolute;left:246.17px;top:267.25px" class="cls_008"><span class="cls_008">PREPARED BY:</span></div>
<div style="position:absolute;left:246.17px;top:311.17px" class="cls_011"><span class="cls_011">PROFESSIONALS REGULATORY AFFAIRS, a</span></div>
<div style="position:absolute;left:246.17px;top:330.73px" class="cls_011"><span class="cls_011">corporation organized and existing under the</span></div>
<div style="position:absolute;left:246.17px;top:350.29px" class="cls_011"><span class="cls_011">laws of the Dubai, UAE, with its head office</span></div>
<div style="position:absolute;left:246.17px;top:369.73px" class="cls_011"><span class="cls_011">located at:  level</span></div>
<div style="position:absolute;left:372.07px;top:369.73px" class="cls_011"><span class="cls_011">6,  office  no.</span></div>
<div style="position:absolute;left:472.18px;top:369.73px" class="cls_011"><span class="cls_011">615,  Dubai</span></div>
<div style="position:absolute;left:246.17px;top:389.29px" class="cls_011"><span class="cls_011">Business  Village  Block  B,  Building  of  the</span></div>
<div style="position:absolute;left:246.17px;top:408.73px" class="cls_011"><span class="cls_011">Department of Economic Development, Port</span></div>
<div style="position:absolute;left:246.17px;top:428.31px" class="cls_011"><span class="cls_011">Saeed, Dubai, United Arab  Emirates.</span></div>
<div style="position:absolute;left:246.17px;top:477.27px" class="cls_006"><span class="cls_006">Dr.Najiba Al Shezawy</span></div>
<div style="position:absolute;left:246.17px;top:494.31px" class="cls_006"><span class="cls_006">Director General</span></div>
<div style="position:absolute;left:246.17px;top:511.47px" class="cls_006"><span class="cls_006">Professionals Regulatory Affairs</span></div>
<div style="position:absolute;left:246.17px;top:526.47px" class="cls_039"><span class="cls_039"> </span><A HREF="mailto:n.alshezawy@pra-me.com">n.alshezawy@pra-me.com</A> </div>
<div style="position:absolute;left:246.17px;top:586.98px" class="cls_008"><span class="cls_008">DATE:</span><span class="cls_014"> </span><span class="cls_015">21</span><span class="cls_016"><sup>st</sup></span><span class="cls_015"> </span><span class="cls_011">June, 2021</span></div>
<div style="position:absolute;left:246.17px;top:637.62px" class="cls_008"><span class="cls_008">TO:</span></div>
<div style="position:absolute;left:246.17px;top:661.98px" class="cls_011"><span class="cls_011">Client name</span></div>
<div style="position:absolute;left:246.17px;top:681.54px" class="cls_011"><span class="cls_011">Designation</span></div>
<div style="position:absolute;left:246.17px;top:701.10px" class="cls_011"><span class="cls_011">Email id</span></div>
<div style="position:absolute;left:30.24px;top:792.92px" class="cls_018"><span class="cls_018">This document is highly confidential. Unauthorized reproduction or distribution of this document or any of its contents in any form or</span></div>
<div style="position:absolute;left:180.77px;top:803.72px" class="cls_018"><span class="cls_018">under any circumstances without prior written consent is prohibited.</span></div>
</div></page>

<page><div style="position:absolute;left:50%;margin-left:-297px;width:595px;height:842px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="af67bbc4-0af7-11ec-a980-0cc47a792c0a_id_af67bbc4-0af7-11ec-a980-0cc47a792c0a_files/background2.jpg" width=595 height=842></div>
<div style="position:absolute;left:22.44px;top:65.50px;color:white;" class="cls_022"><span class="cls_022">MIDDLE EAST MARKET ACCESS</span></div>
<div style="position:absolute;left:26.04px;top:125.86px" class="cls_024"><span class="cls_024">The Middle East life science market is a fast-growing market. This makes it a promising</span></div>
<div style="position:absolute;left:26.04px;top:145.90px" class="cls_024"><span class="cls_024">destination for foreign companies to market their products. However, it can be difficult for</span></div>
<div style="position:absolute;left:26.04px;top:166.06px" class="cls_024"><span class="cls_024">foreign companies to navigate through all the regulatory approvals required to market their</span></div>
<div style="position:absolute;left:26.04px;top:186.10px" class="cls_024"><span class="cls_024">products, which results in lengthy and complex challenges.</span></div>

<div style="position:absolute;left:26.04px;top:226.18px" class="cls_024"><span class="cls_024">To address the challenges for Middle East market access, PRA provides knowledge-</span></div>
<div style="position:absolute;left:26.04px;top:246.25px" class="cls_024"><span class="cls_024">based  regulatory  affairs  in  the  region,  provides  end-to-end  services  to  assist</span></div>
<div style="position:absolute;left:26.04px;top:266.29px" class="cls_024"><span class="cls_024">companies to minimize the compliance related risks and decrease   their timeline to</span></div>
<div style="position:absolute;left:26.04px;top:286.33px" class="cls_024"><span class="cls_024">access the Middle East market.</span></div>
<div style="position:absolute;left:26.04px;top:326.77px" class="cls_024"><span class="cls_024">The Regulatory Affairs consulting engagement will move through several phases.</span></div>
<div style="position:absolute;left:26.04px;top:346.81px" class="cls_024"><span class="cls_024">Every organization is unique, including its Regulatory Affairs needs, capabilities, and</span></div>
<div style="position:absolute;left:26.04px;top:366.85px" class="cls_024"><span class="cls_024">objectives. As a provider our services are custom designed to meet your specific</span></div>
<div style="position:absolute;left:26.04px;top:386.89px" class="cls_024"><span class="cls_024">requirements and goals.</span></div>

<div style="position:absolute;left:26.04px;top:427.23px" class="cls_024"><span class="cls_024">PRA professional experts provide companies with competitive services that include but</span></div>
<div style="position:absolute;left:26.04px;top:447.27px" class="cls_024"><span class="cls_024">not limited to:</span></div>
<div style="position:absolute;left:44.04px;top:467.31px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:467.31px" class="cls_024"><span class="cls_024">Regulatory Affairs consultation & strategy development</span></div>
<div style="position:absolute;left:44.04px;top:487.35px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:487.35px" class="cls_024"><span class="cls_024">Innovative regulatory roadmaps</span></div>
<div style="position:absolute;left:44.04px;top:507.51px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:507.51px" class="cls_024"><span class="cls_024">Company & Manufacturer Registration / Renewal</span></div>
<div style="position:absolute;left:44.04px;top:527.55px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:527.55px" class="cls_024"><span class="cls_024">Product classification, registration / Renewal</span></div>
<div style="position:absolute;left:44.04px;top:547.59px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:547.59px" class="cls_024"><span class="cls_024">Labeling validation and modification</span></div>
<div style="position:absolute;left:44.04px;top:567.63px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:567.63px" class="cls_024"><span class="cls_024">Medical translation [e.g. labels and leaflets]</span></div>
<div style="position:absolute;left:44.04px;top:587.70px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:587.70px" class="cls_024"><span class="cls_024">Product lifecycle management (variations and renewal)</span></div>
<div style="position:absolute;left:44.04px;top:607.74px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:607.74px" class="cls_024"><span class="cls_024">Dossier preparation (CTD & e-CTD)</span></div>
<div style="position:absolute;left:44.04px;top:627.78px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:627.78px" class="cls_024"><span class="cls_024">Laboratory Test and analysis</span></div>

<div style="position:absolute;left:44.04px;top:647.82px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:647.82px" class="cls_024"><span class="cls_024">Pharmacovigilance: implementing a system relating to authorities’ guidelines</span></div>
<div style="position:absolute;left:44.04px;top:667.86px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:667.86px" class="cls_024"><span class="cls_024">Good manufacturing practice (GMP)</span></div>
<div style="position:absolute;left:44.04px;top:688.02px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:688.02px" class="cls_024"><span class="cls_024">Marketing Advertising approvals</span></div>
<div style="position:absolute;left:44.04px;top:708.06px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:708.06px" class="cls_024"><span class="cls_024">Product trademark protection and registration</span></div>
<div style="position:absolute;left:44.04px;top:728.10px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:728.10px" class="cls_024"><span class="cls_024">Importation process approvals</span></div>
<div style="position:absolute;left:44.04px;top:748.14px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:748.14px" class="cls_024"><span class="cls_024">Regulatory affairs candidate Resource</span></div>
<div style="position:absolute;left:44.04px;top:768.20px" class="cls_025"><span class="cls_025">•</span></div>
<div style="position:absolute;left:62.06px;top:768.20px" class="cls_024"><span class="cls_024">outsourcing the Regulatory affairs department</span></div>
<div style="position:absolute;left:44.04px;top:789.44px" class="cls_027"><span class="cls_027">•</span></div>
<div style="position:absolute;left:62.06px;top:788.36px" class="cls_024"><span class="cls_024">Authorized representative facility</span></div>



</div>

</page>

<page>
<div style="position:absolute;left:50%;margin-left:-297px;top:40px;width:595px;height:842px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="af67bbc4-0af7-11ec-a980-0cc47a792c0a_id_af67bbc4-0af7-11ec-a980-0cc47a792c0a_files/background3.jpg" width=595 height=842></div>
<div style="position:absolute;left:19.68px;top:36.92px;color:white;" class="cls_022"><span class="cls_022">REGULATORY AFFAIRS SERVICES</span></div>
<div style="position:absolute;left:49.68px;top:93.70px" class="cls_030"><span class="cls_030">HELATH AUTHORITY (COUNTRY SPECIFIC)</span></div>
<div style="position:absolute;left:60.26px;top:127.42px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  Regulatory file review and corrections (manufacturer and product).</span></div>
<div style="position:absolute;left:60.26px;top:147.58px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  File submissions to MOH.</span></div>
<div style="position:absolute;left:60.26px;top:167.62px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  Follow up with Ministry of Health.</span></div>
<div style="position:absolute;left:60.26px;top:191.74px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  Follow up all required Laboratory tests by MOH.</span></div>
<div style="position:absolute;left:60.26px;top:215.86px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  Obtaining registration certificate.</span></div>
<div style="position:absolute;left:49.68px;top:260.05px" class="cls_032"><span class="cls_032">AGENCY REPRESENTATION</span></div>
<div style="position:absolute;left:60.26px;top:299.65px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  Obtaining Product Classification.</span></div>
<div style="position:absolute;left:60.26px;top:319.69px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  Classification/registration process.</span></div>
<div style="position:absolute;left:60.26px;top:339.85px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  Import permit process.</span></div>
<div style="position:absolute;left:60.26px;top:359.89px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  Invoicing for end user.</span></div>
<div style="position:absolute;left:60.26px;top:380.05px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  Excluding logistics and storage facility.</span></div>
<div style="position:absolute;left:19.68px;top:451.59px;color:white;" class="cls_022"><span class="cls_022">FINANCIAL PROPOSAL</span></div>
<div style="position:absolute;left:33.84px;top:482.31px" class="cls_024"><span class="cls_024">For our services mentioned above, we are charging the below fees:</span></div>
<div style="position:absolute;left:56.54px;top:509.55px" class="cls_036"><span class="cls_036">S.No</span></div>
<div style="position:absolute;left:96.02px;top:509.55px" class="cls_036"><span class="cls_036">Authority</span></div>
<div style="position:absolute;left:245.09px;top:509.55px" class="cls_036"><span class="cls_036">Services</span></div>
<div style="position:absolute;left:440.14px;top:509.55px" class="cls_036"><span class="cls_036">Fees</span></div>
<div style="position:absolute;left:67.34px;top:530.07px" class="cls_024"><span class="cls_024">1</span></div>
<div style="position:absolute;left:165.02px;top:530.07px" class="cls_024"><span class="cls_024">Classification</span></div>
<div style="position:absolute;left:67.34px;top:550.59px" class="cls_024"><span class="cls_024">2</span></div>
<div style="position:absolute;left:165.02px;top:550.59px" class="cls_024"><span class="cls_024">Manufacturer Registration</span></div>
<div style="position:absolute;left:67.34px;top:571.23px" class="cls_024"><span class="cls_024">3</span></div>
<div style="position:absolute;left:165.02px;top:571.23px" class="cls_024"><span class="cls_024">Product Registration</span></div>
<div style="position:absolute;left:67.34px;top:591.78px" class="cls_024"><span class="cls_024">4</span></div>
<div style="position:absolute;left:165.02px;top:591.78px" class="cls_024"><span class="cls_024">Agency Representation</span></div>
<div style="position:absolute;left:67.34px;top:612.30px" class="cls_024"><span class="cls_024">5</span></div>
<div style="position:absolute;left:165.02px;top:612.30px" class="cls_024"><span class="cls_024">eCTD publishing</span></div>
<div style="position:absolute;left:67.34px;top:632.82px" class="cls_024"><span class="cls_024">6</span></div>
<div style="position:absolute;left:165.02px;top:632.82px" class="cls_024"><span class="cls_024">Label review</span></div>
<div style="position:absolute;left:67.34px;top:653.46px" class="cls_024"><span class="cls_024">7</span></div>
<div style="position:absolute;left:165.02px;top:653.46px" class="cls_024"><span class="cls_024">Translation</span></div>
<div style="position:absolute;left:67.34px;top:673.98px" class="cls_024"><span class="cls_024">8</span></div>
<div style="position:absolute;left:165.02px;top:673.98px" class="cls_024"><span class="cls_024">Regulatory reports</span></div>
<div style="position:absolute;left:56.54px;top:712.86px" class="cls_040"><span class="cls_040">Payment terms & conditions:</span></div>
<div style="position:absolute;left:56.54px;top:731.10px" class="cls_020"><span class="cls_020">All amount mentioned are exclusive of 5% VAT.</span></div>

</div>
</page>

<page>
<div style="position:absolute;left:50%;margin-left:-297px;top:40px;width:595px;height:842px;border-style:outset;overflow:hidden">
<div style="position:absolute;left:0px;top:0px">
<img src="af67bbc4-0af7-11ec-a980-0cc47a792c0a_id_af67bbc4-0af7-11ec-a980-0cc47a792c0a_files/background4.jpg" width=595 height=842></div>
<div style="position:absolute;left:19.68px;top:69.82px;color:white;" class="cls_022"><span class="cls_022">PROPOSAL VALIDITY</span></div>
<div style="position:absolute;left:44.04px;top:113.02px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  Kindly note that this proposal is valid for 30 days from the date mentioned in first page of</span></div>
<div style="position:absolute;left:62.06px;top:133.18px" class="cls_024"><span class="cls_024">this proposal.</span></div>
<div style="position:absolute;left:44.04px;top:173.26px" class="cls_025"><span class="cls_025">•</span><span class="cls_026"> </span><span class="cls_024">  The client’s interest to proceed further is kindly expected within the 30-day time frame if</span></div>
<div style="position:absolute;left:62.06px;top:193.30px" class="cls_024"><span class="cls_024">not, this proposal will expire, and the same rates cannot be guaranteed.</span></div>
<div style="position:absolute;left:23.76px;top:252.01px;color:white;" class="cls_022"><span class="cls_022">WHY CHOOSE PRA AS YOUR PARTNER?</span></div>
<div style="position:absolute;left:36.00px;top:316.33px" class="cls_024"><span class="cls_024">Professionals  Regulatory  Affairs</span></div>
<div style="position:absolute;left:227.84px;top:316.33px" class="cls_024"><span class="cls_024">(PRA)  is  a  consultancy  firm  that  advises  and  helps</span></div>
<div style="position:absolute;left:36.00px;top:334.21px" class="cls_024"><span class="cls_024">companies   register   pharmaceutical,   medical   devices,   cosmetics,   personal   care,</span></div>
<div style="position:absolute;left:36.00px;top:352.09px" class="cls_024"><span class="cls_024">supplements, veterinary, herbal products & toys with authorities in the GCC region. It has</span></div>
<div style="position:absolute;left:36.00px;top:369.97px" class="cls_024"><span class="cls_024">an impressive foothold in Middle East that benefits companies in finding their distributors</span></div>
<div style="position:absolute;left:36.00px;top:387.85px" class="cls_024"><span class="cls_024">through us.</span></div>
<div style="position:absolute;left:36.00px;top:428.55px" class="cls_024"><span class="cls_024">With our experienced staff and strong network across the world, we can offer you a</span></div>
<div style="position:absolute;left:36.00px;top:446.43px" class="cls_024"><span class="cls_024">complete   range   of   regulatory   and   pharmacovigilance   support   to   obtain   market</span></div>
<div style="position:absolute;left:36.00px;top:464.31px" class="cls_024"><span class="cls_024">authorizations and approvals in this emerging market.</span></div>
<div style="position:absolute;left:40.08px;top:509.67px" class="cls_024"><span class="cls_024">Our 10+ years of expertise, we can expedite the registrations and market approval</span></div>
<div style="position:absolute;left:40.08px;top:526.71px" class="cls_024"><span class="cls_024">processes. PRA’s comprehensive understanding of the industry and the Middle East</span></div>
<div style="position:absolute;left:40.08px;top:543.99px" class="cls_024"><span class="cls_024">region, we will help our clients achieve their goals in the most efficient and fastest</span></div>
<div style="position:absolute;left:40.08px;top:561.15px" class="cls_024"><span class="cls_024">way possible.</span></div>
<div style="position:absolute;left:40.08px;top:605.82px" class="cls_024"><span class="cls_024">Our firm aims at providing you with a successful business and subsequently,</span></div>
<div style="position:absolute;left:40.08px;top:622.98px" class="cls_024"><span class="cls_024">build a thriving long-term partnership.</span></div>
<div style="position:absolute;left:40.08px;top:667.26px" class="cls_024"><span class="cls_024">Yours Faithfully,</span></div>
<div style="position:absolute;left:40.08px;top:718.86px" class="cls_038"><span class="cls_038">Dr. Najiba Al Shezawy</span></div>
<div style="position:absolute;left:40.08px;top:733.02px" class="cls_038"><span class="cls_038">Director General</span></div>
<div style="position:absolute;left:40.08px;top:749.70px" class="cls_038"><span class="cls_038">Professionals Regulatory Affairs</span></div>
</div>
</page>
';

echo $html;
exit();

$html2pdf->writeHTML($html);
$html2pdf->output('pakainfo.pdf'); 


?>