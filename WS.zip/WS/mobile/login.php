<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('../init.php');
	
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->logincheck))
        {

            $email = $postdata->email;
            $password = $postdata->password;
            $findres = [];
            $user = "none";
            $roleidarr = array();
            $roleslugarr = array();

            $finddoctor = find("first","doctor","*","where doc_email = '".$email."' ",array());
            $findstaff = find("first","staff","*","where staff_email = '".$email."' ",array());
            $findpatient = find("first","patient","*","where email = '".$email."' ",array());

            if($finddoctor)
            {
                if($password == $finddoctor['password'])
                {
                    if($finddoctor['status'] == "N"){
                        $response = "Access Denied";
                    } else {
                        $findres = $finddoctor;
                        $response = "Successfully Login";
                        $user = "Doctor";
                        
                        // $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$finddoctor['role_id']."' ",array());
                        // $findroles = find("all","role","*","where role_id = '".$finddoctor['role_id']."' ",array());
                        $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$finddoctor['role_id']."' ",array());
                        foreach($findroles as $vals){
                            array_push($roleidarr,$vals['module_id']);
                            array_push($roleslugarr,$vals['module_slug']);
                        }
                    }
                } else {
                    $response = "Invalid Password";
                }
            }
            else if($findstaff)
            {
                if($password == $findstaff['password'])
                {
                    $findres = $findstaff;
                    $response = "Successfully Login";
                    $user = "Staff";

                    $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$findstaff['role_id']."' ",array());
                    foreach($findroles as $vals){
                        array_push($roleidarr,$vals['module_id']);
                        array_push($roleslugarr,$vals['module_slug']);
                        // array_push($roleslugarr,$vals['module_link']);
                    }

                } else {
                    $response = "Invalid Password";
                }
            }
            else if($findpatient)
            {
                if($password == $findpatient['password'])
                {
                    $findres = $findpatient;
                    $response = "Successfully Login";
                    $user = "Patient";

                    $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$findpatient['role_id']."' ",array());
                    foreach($findroles as $vals){
                        array_push($roleidarr,$vals['module_id']);
                        array_push($roleslugarr, strtolower($vals['module_slug']));
                    }

                } else {
                    $response = "Invalid Password";
                }
            } 
            else
            {
                if($email == "admin@admin.com" && $password == "123456")
                {
                    $response = "Admin Can't Login";
                    $user = "";
                    
                    // $findroles = find("all","module","*","where 1",array());
                    // // print_r($findroles);
                    // // $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where 1 ",array());
                    // foreach($findroles as $vals){
                    //     array_push($roleidarr,$vals['module_id']);
                    //     // print_r( str_replace(" ","_",strtolower($vals['module_name'])) );
                    //     array_push($roleslugarr, str_replace(" ","_",strtolower($vals['module_name'])));
                    // }

                } else {
                    $response = "User Not Found";
                }
            }
            $result = array("Status"=>"ok","response"=>$response,"findres"=>$findres,"user"=>$user,"roleidarr"=>$roleidarr,"roleslugarr"=>$roleslugarr);
	        echo json_encode($result);
        }
    }
?>