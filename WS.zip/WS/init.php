<?php session_start();
error_reporting(E_ALL);//E_ALL
include_once('includes/config.php');
include_once('includes/dbconnection.php');
// include_once('includes/database_tables.php');
include_once('includes/common_function.php');
include_once('includes/library-function.php');
$link = Db_Connect();
if(!$link)
{
	exit;
}

?>