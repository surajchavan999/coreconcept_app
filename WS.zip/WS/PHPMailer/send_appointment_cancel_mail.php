<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

include("../init.php");
    
    
    $appointment_id = $_POST['appointment_id'];
    
    $findappdetails = find("first","appointment","*","where appointment_id = '".$appointment_id."' ",array());
    
    //for patient
    $findpemail = find("first","patient","*","where patient_id = '".$findappdetails['patient_id']."' ",array());
    
    $to = $findpemail['email'];
    $name = $findpemail['patient_name'];
    $subject = "Appointment Cancellation";
    $fromname = "CoreConcept";
    $message = "
                    Dear $name,
                    <br><br>
                    I am writing to inform you that your appointment scheduled on ".$findappdetails['schedule_date']." at ".$findappdetails['start_time']." to ".$findappdetails['end_time']."  has been cancelled. We apologize for any inconvenience this may cause, and we hope you understand that unforeseen circumstances have arisen that require us to reschedule.
                    <br><br>

                    Please contact us to reschedule your appointment at your earliest convenience. We appreciate your understanding and patience during this time.
                    <br><br>

                    If you have any questions or concerns, please do not hesitate to contact us 
                    <br><br>
                    Best regards,<br>
                    CoreConcept Support Team
                ";
    require 'PHPMailerAutoload.php';
    $mail = new PHPMailer(); // create a new object
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 2; // debugging: 1 = errors and messages, 2 = messages only
    $mail->Host = "smtp.hostinger.com";
    $mail->Port = 465;
    $mail->SMTPAuth = true; // authentication enabled
    $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
    $mail->IsHTML(true);
    $mail->Username = "sendmail@tdtl.info";
    $mail->Password = "Tdtl@23081984";
    $mail->SetFrom("sendmail@tdtl.info",$fromname);
    $mail->Subject = $subject;
    $mail->Body = $message;
    $mail->AddAddress($to,$name);
    if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message has been sent";
    }
    
    
    //for doctor
    
    $finddemail = find("first","doctor","*","where doctor_id = '".$findappdetails['doctor_id']."' ",array());
    
    $to = $finddemail['doc_email'];
    $name = $finddemail['doctor_name'];
    $subject = "Appointment Cancellation with ".$finddemail['doctor_name'];
    $fromname = "CoreConcept";
    $message = "
                    Dear Dr. ".$finddemail['doctor_name'].",
                    <br><br>
                    I am writing to inform you that I need to cancel my appointment scheduled on ".$findappdetails['schedule_date']." at ".$findappdetails['start_time']." to ".$findappdetails['end_time'].". I apologize for any inconvenience this may cause, and I hope you understand that unforeseen circumstances have arisen that require me to reschedule.
                    <br><br>

                    I apologize for any inconvenience this may cause, and I hope you can accommodate my request to reschedule.
                    <br><br>

                    Please let me know of any available dates and times that work for you, and I will do my best to accommodate your schedule.
                    <br><br>

                    Thank you for your time and understanding, and I look forward to hearing back from you soon.
                    <br><br>
                    Sincerely,<br>
                    ".$findpemail['patient_name']."
                ";
    require 'PHPMailerAutoload.php';
    $mail = new PHPMailer(); // create a new object
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 2; // debugging: 1 = errors and messages, 2 = messages only
    $mail->Host = "smtp.hostinger.com";
    $mail->Port = 465;
    $mail->SMTPAuth = true; // authentication enabled
    $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
    $mail->IsHTML(true);
    $mail->Username = "sendmail@tdtl.info";
    $mail->Password = "Tdtl@23081984";
    $mail->SetFrom("sendmail@tdtl.info",$fromname);
    $mail->Subject = $subject;
    $mail->Body = $message;
    $mail->AddAddress($to,$name);
    if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message has been sent";
    }
    
?>