<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->logincheck))
        {

            $email = $postdata->email;
            $password = $postdata->password;
            $findres = [];
            $user = "none";
            $roleidarr = array();
            $roleslugarr = array();

            $finddoctor = find("first","doctor","*","where doc_email = '".$email."' or mobile_number = '".$email."' ",array());
            $findstaff = find("first","staff","*","where staff_email = '".$email."' or mobile_number = '".$email."' ",array());
            $findpatient = find("first","patient","*","where email = '".$email."' or mobile_number = '".$email."' ",array());

            if($finddoctor)
            {
                if($password == $finddoctor['password'])
                {
                    if($finddoctor['status'] == "N"){
                        $response = "Access Denied";
                    } else {
                        $findres = $finddoctor;
                        $response = "Successfully Login";
                        $user = "Doctor";
                        
                        // $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$finddoctor['role_id']."' ",array());
                        // $findroles = find("all","role","*","where role_id = '".$finddoctor['role_id']."' ",array());
                        $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$finddoctor['role_id']."' ",array());
                        foreach($findroles as $vals){
                            array_push($roleidarr,$vals['module_id']);
                            array_push($roleslugarr,$vals['module_slug']);
                        }
                    }
                } else {
                    $response = "Invalid Password";
                }
            }
            else if($findstaff)
            {
                if($password == $findstaff['password'])
                {
                    if($findstaff['status'] == "N"){
                        $response = "Access Denied";
                    } else {
                        $findres = $findstaff;
                        $response = "Successfully Login";
                        $user = "Staff";
    
                        $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$findstaff['role_id']."' ",array());
                        foreach($findroles as $vals){
                            array_push($roleidarr,$vals['module_id']);
                            array_push($roleslugarr,$vals['module_slug']);
                            // array_push($roleslugarr,$vals['module_link']);
                        }
                    }
                } else {
                    $response = "Invalid Password";
                }
            }
            else if($findpatient)
            {
                if($password == $findpatient['password'])
                {
                    $findres = $findpatient;
                    $response = "Successfully Login";
                    $user = "Patient";

                    $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$findpatient['role_id']."' ",array());
                    foreach($findroles as $vals){
                        array_push($roleidarr,$vals['module_id']);
                        array_push($roleslugarr, strtolower($vals['module_slug']));
                    }

                } else {
                    $response = "Invalid Password";
                }
            } 
            else
            {
                $findadmin = find("first","admintable","*","where email = '".$email."' ",array());
                if($findadmin['password'] == $password)
                {
                    // if($email == "admin@admin.com" && $password == "123456")
                    if($findadmin)
                    {
                        // $email = "admin@admin.com";
                        // $password = "123456";
    
                        $response = "Successfully Login";
                        $user = "Admin";
    
                        $findroles = find("all","module","*","where 1",array());
                        // print_r($findroles);
                        // $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where 1 ",array());
                        foreach($findroles as $vals){
                            array_push($roleidarr,$vals['module_id']);
                            // print_r( str_replace(" ","_",strtolower($vals['module_name'])) );
                            array_push($roleslugarr, str_replace(" ","_",strtolower($vals['module_name'])));
                        }
    
                    } else {
                        $response = "User Not Found";
                    }
                } else {
                    $response = "Invalid Password";
                }
            }
            $result = array("Status"=>"ok","response"=>$response,"findres"=>$findres,"user"=>$user,"roleidarr"=>$roleidarr,"roleslugarr"=>$roleslugarr);
	        echo json_encode($result);
        }
        
        if(isset($postdata->changepassword))
        {
            $oldpswd = $postdata->oldpswd;
            $newpswd = $postdata->newpswd;
            $repswd = $postdata->repswd;
            $user_id = $postdata->user_id;
            $user = $postdata->user;
            $response = "";
            $se = "";
            
            if($user == "Patient"){
                $findoldpswdp = find("first","patient","*","where patient_id = '".$user_id."' ",array());
                $email = $findoldpswdp['email'];
                $name = $findoldpswdp['patient_name'];
                if($findoldpswdp['password'] == $oldpswd){
                    if($newpswd == $repswd){
                        $setvalue = "password=:password";
                        $wherecon = "where patient_id = '".$user_id."' ";
                        $execon = array(":password"=>$newpswd);
                        $updatepswd = update("patient",$setvalue,$wherecon,$execon);
                        if($updatepswd){ 
                            $response = "Password Changed"; 
                            $se = "Success"; 
                            savenotification("0",$user_id,"",$user,"Password Change","Password Change Successfully"); 
                            
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL,"https://tdtl.info/coreconcept/ws/PHPMailer/send_change_password.php");
                            curl_setopt($ch, CURLOPT_POST, 1);
                            curl_setopt($ch, CURLOPT_POSTFIELDS,"email=$email&name=$name");
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                            $server_output = curl_exec($ch);
                            curl_close ($ch);
                        }
                    } else {
                        $response = "Password Does'nt Match";
                        $se = "Error";
                    }
                } else {
                    $response = "Old Password Does'nt Match";
                    $se = "Error";
                }
            }
            
            if($user == "Doctor"){
                $findoldpswdp = find("first","doctor","*","where doctor_id = '".$user_id."' ",array());
                $email = $findoldpswdp['doc_email'];
                $name = $findoldpswdp['doctor_name'];
                if($findoldpswdp['password'] == $oldpswd){
                    if($newpswd == $repswd){
                        $setvalue = "password=:password";
                        $wherecon = "where doctor_id = '".$user_id."' ";
                        $execon = array(":password"=>$newpswd);
                        $updatepswd = update("doctor",$setvalue,$wherecon,$execon);
                        if($updatepswd){ 
                            $response = "Password Changed"; 
                            $se = "Success"; 
                            savenotification("0",$user_id,"",$user,"Password Change","Password Change Successfully"); 
                            
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL,"https://tdtl.info/coreconcept/ws/PHPMailer/send_change_password.php");
                            curl_setopt($ch, CURLOPT_POST, 1);
                            curl_setopt($ch, CURLOPT_POSTFIELDS,"email=$email&name=$name");
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                            $server_output = curl_exec($ch);
                            curl_close ($ch);
                        }
                    } else {
                        $response = "Password Does'nt Match";
                        $se = "Error";
                    }
                    
                } else {
                    $response = "Old Password Does'nt Match";
                    $se = "Error";
                }
            }
            
            if($user == "Staff"){
                $findoldpswdp = find("first","staff","*","where staff_id = '".$user_id."' ",array());
                $email = $findoldpswdp['staff_email'];
                $name = $findoldpswdp['staff_name'];
                if($findoldpswdp['password'] == $oldpswd){
                    if($newpswd == $repswd){
                        $setvalue = "password=:password";
                        $wherecon = "where staff_id = '".$user_id."' ";
                        $execon = array(":password"=>$newpswd);
                        $updatepswd = update("staff",$setvalue,$wherecon,$execon);
                        if($updatepswd){ 
                            $response = "Password Changed"; 
                            $se = "Success"; 
                            savenotification("0",$user_id,"",$user,"Password Change","Password Change Successfully"); 
                            
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL,"https://tdtl.info/coreconcept/ws/PHPMailer/send_change_password.php");
                            curl_setopt($ch, CURLOPT_POST, 1);
                            curl_setopt($ch, CURLOPT_POSTFIELDS,"email=$email&name=$name");
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                            $server_output = curl_exec($ch);
                            curl_close ($ch);
                        }
                    } else {
                        $response = "Password Does'nt Match";
                        $se = "Error";
                    }
                    
                } else {
                    $response = "Old Password Does'nt Match";
                    $se = "Error";
                }
            }
            
            if($user == "Admin"){
                $findoldpswdp = find("first","admintable","*","where admin_id = '1' ",array());
                if($findoldpswdp['password'] == $oldpswd){
                    if($newpswd == $repswd){
                        $setvalue = "password=:password";
                        $wherecon = "where admin_id = '1' ";
                        $execon = array(":password"=>$newpswd);
                        $updatepswd = update("admintable",$setvalue,$wherecon,$execon);
                        if($updatepswd){ 
                            $response = "Password Changed"; 
                            $se = "Success"; 
                        }
                    } else {
                        $response = "Password Does'nt Match";
                        $se = "Error";
                    }
                } else {
                    $response = "Old Password Does'nt Match";
                    $se = "Error";
                }
            }
            
            
            $result = array("Status"=>"ok","response"=>$response,"se"=>$se);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fpemailotp))
        {
            $email = $postdata->email;
            
            $findpatient = find("first","patient","*","where email = '".$email."' ",array());
            $finddoctor = find("first","doctor","*","where doc_email = '".$email."' ",array());
            $findstaff = find("first","staff","*","where staff_email = '".$email."' ",array());
            $response = "";
            if($findpatient){
                $response = "Welcome ".$findpatient['patient_name'];
                $name = $findpatient['patient_name'];
                $userdata = $findpatient;
                $user = "patient";
                $sendotp = rand(1000,9999);
                
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL,"https://tdtl.info/coreconcept/ws/PHPMailer/send_reset_password.php");
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS,"sendotp=$sendotp&email=$email&name=$name");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $server_output = curl_exec($ch);
                curl_close ($ch);
                
            } else if($findstaff){
                $response = "Welcome ".$findstaff['staff_name'];
                $name = $findstaff['staff_name'];
                $userdata = $findstaff;
                $user = "staff";
                $sendotp = rand(1000,9999);
                
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL,"https://tdtl.info/coreconcept/ws/PHPMailer/send_reset_password.php");
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS,"sendotp=$sendotp&email=$email&name=$name");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $server_output = curl_exec($ch);
                curl_close ($ch);
                
                
            } else if($finddoctor){
                $response = "Welcome ".$finddoctor['doctor_name'];
                $name = $finddoctor['doctor_name'];
                $userdata = $finddoctor;
                $user = "doctor";
                $sendotp = rand(1000,9999);
                
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL,"https://tdtl.info/coreconcept/ws/PHPMailer/send_reset_password.php");
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS,"sendotp=$sendotp&email=$email&name=$name");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $server_output = curl_exec($ch);
                curl_close ($ch);
                
            } else {
                $response = "User Not Found";
            }
            
            $result = array("Status"=>"ok","response"=>$response,"userdata"=>$userdata,"sendotp"=>$sendotp,"user"=>$user);
	        echo json_encode($result);
        }
        
        if(isset($postdata->submitnewpass))
        {
            $email = $postdata->email;
            $npswd = $postdata->npswd;
            $user = $postdata->user;
            if($user == "patient"){
                $findid = find("first","patient","*","where email = '".$email."' ",array());
                $updatepass = update("patient","password=:password","where email = '".$email."' ",array(":password"=>$npswd));
                if($updatepass){ savenotification("0",$findid['patient_id'],"",$user,"Password Reset","Password Reset Successfully"); }
            }
            if($user == "staff"){
                $findid = find("first","staff","*","where staff_email = '".$email."' ",array());
                $updatepass = update("staff","password=:password","where staff_email = '".$email."' ",array(":password"=>$npswd));
                if($updatepass){ savenotification("0",$findid['staff_id'],"",$user,"Password Reset","Password Reset Successfully"); }
            }
            if($user == "doctor"){
                $findid = find("first","doctor","*","where doc_email = '".$email."' ",array());
                $updatepass = update("doctor","password=:password","where doc_email = '".$email."' ",array(":password"=>$npswd));
                if($updatepass){ savenotification("0",$findid['doctor_id'],"",$user,"Password Reset","Password Reset Successfully"); }
            }
            // if($user == "Admin"){
            //     $findid = find("first","admintable","*","where email = '".$email."' ",array());
            //     $updatepass = update("admintable","password=:password","where email = '".$email."' ",array(":password"=>$npswd));
            //     if($updatepass){ savenotification("0",$findid['admin_id'],"",$user,"Password Reset","Password Reset Successfully"); }
            // }
            $result = array("Status"=>"ok","updatepass"=>$updatepass);
	        echo json_encode($result);
        }
    }
?>