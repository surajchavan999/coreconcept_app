<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));
		
		if(isset($postdata->datanoti))
        {
            $user = $postdata->user;
            $user_id = $postdata->user_id;
            
            if($user == "Patient"){
                $findnoti = find("all","notifications","*","where sent_to_id = '".$user_id."' and sent_to_user = '".$user."' ",array());
            }
            if($user == "Staff"){
                $findnoti = find("all","notifications","*","where sent_to_id = '".$user_id."' and sent_to_user = '".$user."' ",array());
            }
            if($user == "Doctor"){
                $findnoti = find("all","notifications","*","where sent_to_id = '".$user_id."' and sent_to_user = '".$user."' ",array());
            }
            if($user == "Admin"){
                $findnoti = find("all","notifications","*","where 1 ",array());
            }
            
            $result = array("Status"=>"ok","findnoti"=>$findnoti);
	        echo json_encode($result);
        }
	}
?>