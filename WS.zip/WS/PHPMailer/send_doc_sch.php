<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

include("../init.php");
    
    $docid = $_POST['docid'];
    
    $findddetails = find("first","doctor","*","where doctor_id = '".$docid."' ",array());
    
    $to = $findddetails['doc_email'];
    $subject = "Schedule Added or Update";//$_POST["subject"];
    $name = $findddetails['doctor_name'];
    $fromname = "CoreConcept";
    $message = "
                    Dear $name,
                    <br><br>
                    This is to inform you that your schedule has been updated in our portal. To see The Changes login to portal.
                    <br><br>
                    Please log in to your account to view the updated schedule. If you have any questions or concerns, please do not hesitate to contact us.
                    <br><br>
                    Thank you for choosing us as your healthcare provider.
                    <br><br>
                    Best regards,<br>
                    CoreConcept Support Team
                ";
    
    
    require 'PHPMailerAutoload.php';
    $mail = new PHPMailer(); // create a new object
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 2; // debugging: 1 = errors and messages, 2 = messages only
    $mail->Host = "smtp.hostinger.com";
    $mail->Port = 465;
    $mail->SMTPAuth = true; // authentication enabled
    $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
    $mail->IsHTML(true);
    $mail->Username = "sendmail@tdtl.info";
    $mail->Password = "Tdtl@23081984";
    $mail->SetFrom("sendmail@tdtl.info",$fromname);
    $mail->Subject = $subject;
    $mail->Body = $message;
    $mail->AddAddress($to,$name);
    
    // $filename = $_POST['filename'];
    // $fileattach = "../uploads/proposalfiles/".$filename.".pdf"; // full path
    // $mail->AddAttachment($fileattach);

    //$mail->addcc('sunnicse@gmail.com');
    if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message has been sent";
    }
?>