<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));
		
		if(isset($postdata->savedietresult))
	    {
            $appid = $postdata->appid;
            $mesauredate = $postdata->mesauredate;
            $mesurearr = [];
            $savedietresult = 0;
            $updatedietresult = false;
            foreach($postdata as $k=>$v){ if($k == 'appid' || $k == 'mesauredate' || $k == 'savedietresult'){}else{ $mesurearr[$k] = $v; } }
           // print_r($mesurearr);
            $findappdetails = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            $pid = $findappdetails['patient_id'];
            
            $findalreadyfilledresult = find("first","dietplanallocateresult","*","where patient_id = '".$pid."' and appointment_id = '".$appid."' and plan_date = '".$mesauredate."' ",array());
            if($findalreadyfilledresult){
                $setvalue = "plan_data=:plan_data";
                $wherecon = "where patient_id = '".$pid."' and appointment_id = '".$appid."' and plan_date = '".$mesauredate."' ";
                $execon = array(
                        ":plan_data"=>json_encode($mesurearr)
                    );
                $updatedietresult = update("dietplanallocateresult",$setvalue,$wherecon,$execon);
            } else {
                $fields = "patient_id,appointment_id,plan_date,plan_data,created_date";
                $values = ":patient_id,:appointment_id,:plan_date,:plan_data,:created_date";
                $exe = array(
                    ":patient_id"=>$pid,
                    ":appointment_id"=>$appid,
                    ":plan_date"=>$mesauredate,
                    ":plan_data"=>json_encode($mesurearr),
                    ":created_date"=>date("Y-m-d H:i:s"),
                    );
                $savedietresult = save("dietplanallocateresult",$fields,$values,$exe);
            }
            
            $result = array("Status"=>"ok","savedietresult"=>$savedietresult,"updatedietresult"=>$updatedietresult);
            echo json_encode($result);
	    }
	    
		if(isset($postdata->fetchresult))
		{
            $appid = $postdata->appid;
            $findappdetails = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            $findpdetails = find("first","patient","*","where patient_id = '".$findappdetails['patient_id']."' ",array());
            $finddietplanallocate = find("first","dietplanallocate","*","where appointment_id = '".$appid."' and patient_id = '".$findappdetails['patient_id']."' ",array());
            
            $finddietresult = find("all","dietplanallocateresult","*","where patient_id = '".$findappdetails['patient_id']."' and appointment_id = '".$appid."' ",array());
            
            $fromdate = $finddietplanallocate['fromdate'];
            $todate = $finddietplanallocate['todate'];
            $gapdays = $finddietplanallocate['results_days'];
            $dietresult = array();
            for ($currentDate = strtotime($fromdate); $currentDate <= strtotime($todate); $currentDate += ($gapdays * 86400)) {
                $Store = date('Y-m-d', $currentDate);
                $finddietresults = find("first","dietplanallocateresult","*","where patient_id = '".$findappdetails['patient_id']."' and appointment_id = '".$appid."' and plan_date = '$Store' ",array());
                if($finddietresults){
                    $plandata = json_decode($finddietresults['plan_data']);
                } else { $plandata = json_decode("{}"); }
                $temparr = array(
                    "date"=>$Store,
                    "result"=>$plandata
                    );
                
                // print_r($temparr);
                $dietresult[] = $temparr;
            }
            // print_r($dietresult);
            
            $result = array("Status"=>"ok","finddietplanallocate"=>$finddietplanallocate,"findpdetails"=>$findpdetails,"finddietresult"=>$finddietresult,"dietresult"=>$dietresult);
            echo json_encode($result);
		}
		
		if(isset($postdata->fetchdietmain))
		{
            // $dietid = $postdata->dietid;
            $appid = $postdata->appid;
		    $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            
            $findappdetails = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            
            $finddietplanallocate = find("first","dietplanallocate","*","where appointment_id = '".$appid."' and patient_id = '".$findappdetails['patient_id']."' ",array());
            
            $finddietresult = find("all","dietplanallocateresult","*","where patient_id = '".$findappdetails['patient_id']."' and appointment_id = '".$appid."' ",array());
            
            $fromdate = $finddietplanallocate['fromdate'];
            $todate = $finddietplanallocate['todate'];
            $gapdays = $finddietplanallocate['results_days'];
            $dietresult = array();
            for ($currentDate = strtotime($fromdate); $currentDate <= strtotime($todate); $currentDate += ($gapdays * 86400)) {
                $Store = date('Y-m-d', $currentDate);
                $finddietresults = find("first","dietplanallocateresult","*","where patient_id = '".$findappdetails['patient_id']."' and appointment_id = '".$appid."' and plan_date = '$Store' ",array());
                if($finddietresults){
                    $plandata = json_decode($finddietresults['plan_data']);
                } else { $plandata = json_decode("{}"); }
                $temparr = array("date"=>$Store,"result"=>$plandata);
                // print_r($temparr);
                $dietresult[] = $temparr;
            }
            
            // $findgivendiet = find("first","dietpatienttreatment","*","where patient_id = '".$findpid['patient_id']."' and diettreatment_id = '".$dietid."' ",array());
            
            // $finddites = find("first","diettreatment","*","where diettreatment = '".$dietid."' and patient_id = '".$findpid['patient_id']."' ",array());
            
            $result = array("Status"=>"ok","findpid"=>$findpid,"dietresult"=>$dietresult,"finddietplanallocate"=>$finddietplanallocate,"finddietresult"=>$finddietresult);//,"finddites"=>$finddites,"findgivendiet"=>$findgivendiet,"findpid"=>$findpid);
            echo json_encode($result);
		}
		
		if(isset($postdata->fetchdietpd))
		{
            $dietid = $postdata->dietid;
		    $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            
            $findgivendiet = find("first","dietpatienttreatment","*","where patient_id = '".$findpid['patient_id']."' and diettreatment_id = '".$dietid."' ",array());
            
            $finddites = find("first","diettreatment","*","where diettreatment = '".$dietid."' and patient_id = '".$findpid['patient_id']."' ",array());
            
            $result = array("Status"=>"ok","finddites"=>$finddites,"findgivendiet"=>$findgivendiet);
            echo json_encode($result);
		}
		
		if(isset($postdata->savedpt))
		{
            $dietid = $postdata->dietid;
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $dietdata = $postdata->dietdata;
            
            $findalreadydiet = find("first","dietpatienttreatment","*","where patient_id = '".$findpid['patient_id']."' and diettreatment_id = '".$dietid."' ",array());
            
            if($findalreadydiet){
                $setvalue = "ditedata=:ditedata";
                $wherecon = "where patient_id = '".$findpid['patient_id']."' and diettreatment_id = '".$dietid."' ";
                $execon = array(":ditedata"=>$dietdata);
                $updatedtp = update("dietpatienttreatment",$setvalue,$wherecon,$execon);
            } else {
                $fields = "diettreatment_id,patient_id,ditedata,updated_date";
                $values = ":diettreatment_id,:patient_id,:ditedata,:updated_date";
                $exe = array(
                    ":diettreatment_id"=>$dietid,
                    ":patient_id"=> $findpid['patient_id'],
                    ":ditedata"=> $dietdata,
                    ":updated_date"=>date("Y-m-d H:i:s"),
                );
                $savedtp = save("dietpatienttreatment",$fields,$values,$exe);
		    }
		    
		    $result = array("Status"=>"ok","savedtp"=>$savedtp,"updatedtp"=>$updatedtp);
            echo json_encode($result);
		}
		
		if(isset($postdata->savedptpd))
		{
            $dietid = $postdata->dietid;
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $dietdata = $postdata->dietdata;
            
            $findalreadydiet = find("first","dietpatienttreatment","*","where patient_id = '".$findpid['patient_id']."' and diettreatment_id = '".$dietid."' ",array());
            
            if($findalreadydiet){
                $setvalue = "ditedata=:ditedata";
                $wherecon = "where patient_id = '".$findpid['patient_id']."' and diettreatment_id = '".$dietid."' ";
                $execon = array(":ditedata"=>$dietdata);
                $updatedtp = update("dietpatienttreatment",$setvalue,$wherecon,$execon);
            } else {
                $fields = "diettreatment_id,patient_id,ditedata,updated_date";
                $values = ":diettreatment_id,:patient_id,:ditedata,:updated_date";
                $exe = array(
                    ":diettreatment_id"=>$dietid,
                    ":patient_id"=> $findpid['patient_id'],
                    ":ditedata"=> $dietdata,
                    ":updated_date"=>date("Y-m-d H:i:s"),
                );
                $savedtp = save("dietpatienttreatment",$fields,$values,$exe);
		    }
		    
		    $result = array("Status"=>"ok","savedtp"=>$savedtp,"updatedtp"=>$updatedtp);
            echo json_encode($result);
		}
		
		if(isset($postdata->fetchaddfdata))
		{
		    $appid = $postdata->appid;
		    $user = $postdata->user;
		    $userid = $postdata->userid;
		  //  if($user == "Admin"){
                $findappdetails = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
                $findappdetailp = find("first","patient","*","where patient_id = '".$findappdetails['patient_id']."' ",array());
                
                $findditeformdetails = find("all","dietdetailsform","form_key,form_value","where appoitment_id = '".$appid."' and patient_id = '".$findappdetails['patient_id']."' ",array());
                // print_r($findditeformdetails);
                
            // }
		    
		    $result = array("Status"=>"ok","findappdetails"=>$findappdetails,"findappdetailp"=>$findappdetailp,"findditeformdetails"=>$findditeformdetails);
            echo json_encode($result);
		}
		
// 		if(isset($postdata->adddietdetiaform))
		if(isset($_POST['adddietdetiaform']))
		{
	        $allfilesname = array();
		    if(isset($_FILES['labfiles'])){
		        $findlabfiles = find("first","dietdetailsform","*","where form_key = 'labfilesup' ",array());
		        if($findlabfiles){
		            $prevfiles = json_decode($findlabfiles['form_value']);
                    $allfilesname = $prevfiles;
		        }
		        $count = count($_FILES['labfiles']['name']);
		        for ($i = 0; $i < $count; $i++) {
                    $file_ext = strtolower(explode('.',$_FILES['labfiles']['name'][$i])[1]);
                    $filename = explode('.',$_FILES['labfiles']['name'][$i])[0];
                    array_push($allfilesname,$filename."_".$_POST['appid'].".".$file_ext);
                    $tempname = $_FILES['labfiles']['tmp_name'][$i];
                    $targetwithfile = "uploads/labfiles/".$filename."_".$_POST['appid'].".".$file_ext;
                    move_uploaded_file($tempname,$targetwithfile);
		        }
		    }
		    $_POST['labfilesup'] = json_encode($allfilesname);
		    
		    $appid = $_POST['appid'];
		    $savedietmeta = 0;
            $updatedietform = false;
		    $findappdetilas = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
		    $findalreadyfilleddiet = find("all","dietdetailsform","*","where appoitment_id = '".$appid."' and patient_id = '".$findappdetilas['patient_id']."' ",array());
		    if($findalreadyfilleddiet){
		        $setvalues = "form_value=:form_value";
		        foreach($_POST as $k=>$v){
		            if($k == "adddietdetiaform" || $k == "appid"){}else{
		                $findalreadykey = find("all","dietdetailsform","*","where appoitment_id = '".$appid."' and patient_id = '".$findappdetilas['patient_id']."' and form_key = '".$k."' ",array());
		                if($findalreadykey){
    		                $wherecon = "where form_key = '".$k."' and appoitment_id = '".$appid."' and patient_id = '".$findappdetilas['patient_id']."' ";
    		                $execon = array(":form_value"=>$v);
    		                $updatedietform = update("dietdetailsform",$setvalues,$wherecon,$execon);
		                }else {
		                    $fields = "appoitment_id,patient_id,form_key,form_value,created_date";
    		                $values = ":appoitment_id,:patient_id,:form_key,:form_value,:created_date";
    		                $exe = array(
                                ":appoitment_id"=> $appid,
                                ":patient_id"=> $findappdetilas['patient_id'],
                                ":form_key"=> $k,
                                ":form_value"=> $v,
                                ":created_date"=> date("Y-m-d H:i:s")
                            );
                            $savedietmeta = save("dietdetailsform",$fields,$values,$exe);
		                }
		            }
		        }
		    } else {
    		    $fields = "appoitment_id,patient_id,form_key,form_value,created_date";
    		    $values = ":appoitment_id,:patient_id,:form_key,:form_value,:created_date";
                    foreach($_POST as $k=>$v){
                        if($k == "adddietdetiaform" || $k == "appid"){}else{
                            $exe = array(
                                ":appoitment_id"=> $appid,
                                ":patient_id"=> $findappdetilas['patient_id'],
                                ":form_key"=> $k,
                                ":form_value"=> $v,
                                ":created_date"=> date("Y-m-d H:i:s")
                            );
                            $savedietmeta = save("dietdetailsform",$fields,$values,$exe);
                        }
                    }
		    }
		    
		    $result = array("Status"=>"ok","savedietmeta"=>$savedietmeta,"updatedietform"=>$updatedietform);
            echo json_encode($result);
		}
		
		if(isset($postdata->datadelfile))
		{
            $appid = $postdata->appid;
            $filename = $postdata->filename;
            $findappdetilas = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            $patient_id = $findappdetilas['patient_id'];
            
            $findlabfiles = find("first","dietdetailsform","*","where appoitment_id = '".$appid."' and patient_id = '".$patient_id."' and form_key = 'labfilesup' ",array());
            $labfiles = json_decode($findlabfiles['form_value']);
            
            $newlafiles = [];
            foreach($labfiles as $k=>$v){
                if($filename != $v){
                    array_push($newlafiles,$v);
                }
            }
            
            $updatefile = update("dietdetailsform","form_value=:form_value","where appoitment_id = '".$appid."' and patient_id = '".$patient_id."' and form_key = 'labfilesup' ",array(":form_value"=>json_encode($newlafiles)));
            // $deletefile = delete("dietdetailsform","where appoitment_id = '".$appid."' and patient_id = '".$patient_id."' and form_key = 'labfilesup' ",array());
            
            $result = array("Status"=>"ok","updatefile"=>$updatefile);
            echo json_encode($result);
		}
	}
?>