<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));
		
		
		if(isset($postdata->saveorthoneurotbaleformb))
		{
            $puid = $postdata->puid;
            $appid = $postdata->appid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $patientid = $findpid['patient_id'];
            
            $updatefbdata = false;
            $saveonfbdata = true;
            
            $findalreadybtabledata = find("first","orthoneurotableformb","*","where patient_id = '".$patientid."' and appointment_id = '".$appid."' ",array());
            if($findalreadybtabledata){
                $setvalue = "tabledata=:tabledata";
                $wherecon = "where patient_id = '".$patientid."' and appointment_id = '".$appid."' ";
                $execon = array(":tabledata"=>json_encode($postdata));
                $updatefbdata = update("orthoneurotableformb",$setvalue,$wherecon,$execon);
            } else {
                $fields = "patient_id,appointment_id,tabledata,created_date";
                $values = ":patient_id,:appointment_id,:tabledata,:created_date";
                $exe = array(":patient_id"=>$patientid,":appointment_id"=>$appid,":tabledata"=>json_encode($postdata),":created_date"=>date("Y-m-d H:i:s"));
                $saveonfbdata = save("orthoneurotableformb",$fields,$values,$exe);
            }
            
            
            $result = array("Status"=>"ok","saveonfbdata"=>$saveonfbdata,"updatefbdata"=>$updatefbdata);
            echo json_encode($result);
		}
		
		if(isset($postdata->saveorthoneurotbaleforma))
		{
            $puid = $postdata->puid;
            $appid = $postdata->appid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $patientid = $findpid['patient_id'];
            
            $saveonfadata = 0;
            $updatefadata = false;
            
            $findalreadytabledata = find("first","orthoneurotableforma","*","where patient_id = '".$patientid."' and appointment_id = '".$appid."' ",array());
            if($findalreadytabledata){
                $setvalue = "tabledata=:tabledata";
                $wherecon = "where patient_id = '".$patientid."' and appointment_id = '".$appid."' ";
                $execon = array(":tabledata"=>json_encode($postdata));
                $updatefadata = update("orthoneurotableforma",$setvalue,$wherecon,$execon);
            } else {
                $fields = "patient_id,appointment_id,tabledata,created_date";
                $values = ":patient_id,:appointment_id,:tabledata,:created_date";
                $exe = array(":patient_id"=>$patientid,":appointment_id"=>$appid,":tabledata"=>json_encode($postdata),":created_date"=>date("Y-m-d H:i:s"));
                $saveonfadata = save("orthoneurotableforma",$fields,$values,$exe);
            }
            
            $result = array("Status"=>"ok","saveonfadata"=>$saveonfadata,"updatefadata"=>$updatefadata);
            echo json_encode($result);
		}
		
		if(isset($postdata->saveortoneuroformb))
		{
		    $appid = $postdata->appid;
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $patientid = $findpid['patient_id'];
            $saveorthoneuroformb = 0;
            $updateonformb = false;
            
            $findalreadyon = find("all","orthoneurodataformb","*","where patient_id = '".$patientid."' and appointment_id = '".$appid."' ",array());
            if($findalreadyon){
                foreach($postdata as $k=>$v){
                    $findalreadykey = find("first","orthoneurodataformb","*","where patient_id = '".$patientid."' and appointment_id = '".$appid."' and meta_key = '".$k."' ",array());
                    if($findalreadykey){
                        $setvalue = "meta_value=:meta_value";
                        $where = "where patient_id = '".$patientid."' and appointment_id = '".$appid."' and meta_key = '".$k."' ";
                        $execon = array(":meta_value"=>$v);
                        $updateonformb = update("orthoneurodataformb",$setvalue,$where,$execon);
                    } else {
                        if($k == "orthoneurodataformb" || $k == "appid" || $k == "puid"){}else{
                            $fields = "patient_id,appointment_id,meta_key,meta_value,created_date";
                            $values = ":patient_id,:appointment_id,:meta_key,:meta_value,:created_date";
                            $exe = array(
                                    ":patient_id"=>$patientid,
                                    ":appointment_id"=>$appid,
                                    ":meta_key"=>$k,
                                    ":meta_value"=>$v,
                                    ":created_date"=>date("Y-m-d H:i:s"),
                                );
                            $saveorthoneuroformb = save("orthoneurodataformb",$fields,$values,$exe);
                        }
                    }
                }
            } else {
                foreach($postdata as $k=>$v){
                    if($k == "orthoneurodataformb" || $k == "appid" || $k == "puid"){}else{
                        $fields = "patient_id,appointment_id,meta_key,meta_value,created_date";
                        $values = ":patient_id,:appointment_id,:meta_key,:meta_value,:created_date";
                        $exe = array(
                                ":patient_id"=>$patientid,
                                ":appointment_id"=>$appid,
                                ":meta_key"=>$k,
                                ":meta_value"=>$v,
                                ":created_date"=>date("Y-m-d H:i:s"),
                            );
                        $saveorthoneuroformb = save("orthoneurodataformb",$fields,$values,$exe);
                    }
                }
            }
            $result = array("Status"=>"ok","saveorthoneuroformb"=>$saveorthoneuroformb,"updateonformb"=>$updateonformb);
            echo json_encode($result);
		}
    
        if(isset($postdata->fetchorthoneuradataformb))
        {
            $puid = $postdata->puid;
            $appid = $postdata->appid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $patientid = $findpid['patient_id'];
            
            $findorthoneurodataformb = find("all","orthoneurodataformb","*","where patient_id = '".$patientid."' and appointment_id = '".$appid."' ",array());
            
            $findtableformbdata = find("first","orthoneurotableformb","*","where patient_id = '".$patientid."' ",array());
            
            $result = array("Status"=>"ok","findpid"=>$findpid,"findorthoneurodataformb"=>$findorthoneurodataformb,"findtableformbdata"=>$findtableformbdata);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchorthoneuradata))
        {
            $puid = $postdata->puid;
            $appid = $postdata->appid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $patientid = $findpid['patient_id'];
            
            $findorthoneurodata = find("all","orthoneurodata","*","where patient_id = '".$patientid."' and appointment_id = '".$appid."' ",array());
            
            $findtableformadata = find("first","orthoneurotableforma","*","where patient_id = '".$patientid."' and appointment_id = '".$appid."' ",array());
            
            $result = array("Status"=>"ok","findpid"=>$findpid,"findorthoneurodata"=>$findorthoneurodata,"findtableformadata"=>$findtableformadata);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchonlyactive))
        {
            $user = $postdata->user;
            $user_id = $postdata->user_id;
            $puid = (isset($postdata->puid)) ? $postdata->puid : "";
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $patientid = $findpid['patient_id'];
            
            // $findconsulteddata = find("first","patient_history_obser","*","where patient_id = '".$patientid."' ",array());

            $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id";
            if($user == "Doctor")
            {
                $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus","where appointment.status = 'A' AND appointment.doc_id = '".$user_id."' and appointment.patient_id = '".$findpid['patient_id']."' order by schedule_date DESC",array());
            }
            if($user == "Patient")
            {
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus","where appointment.status = 'A' AND appointment.patient_id = '".$user_id."' order by schedule_date DESC",array());
            }
            if($user == "Staff")
            {
                $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus","where appointment.status = 'A' and appointment.patient_id = '".$findpid['patient_id']."' order by schedule_date DESC" ,array());
            }
            if($user == "Admin")
            {
                $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
                $findallappoitment = find("all",$tableappoit,"*, appointment.status as astatus","where appointment.status = 'A' and appointment.patient_id = '".$findpid['patient_id']."' order by schedule_date DESC ",array());
            }
                
            
            $result = array("Status"=>"ok","findallappoitment"=>$findallappoitment);//,"findconsulteddata"=>$findconsulteddata);
	        echo json_encode($result);
        }

        if(isset($postdata->conssavenewwithdetails))
        {
            $appid = $postdata->appid;
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $patientid = $findpid['patient_id'];
            $phistory = "";
            $pobservation = "";
            $consulteddata = json_encode($postdata);
            
            $savepho = 0;
            $updatepho = false;
            // print_r($consulteddata);
            // exit();
            $findalreadycons = find("first","patient_history_obser","*","where patient_id = '".$patientid."' and appoitment_id = '".$appid."' ",array());
            if($findalreadycons){
                $setvalue = "consulteddata=:consulteddata";
                $wherecon = "where patient_id = '".$patientid."' and appoitment_id = '".$appid."' ";
                $execonn = array(":consulteddata"=>$consulteddata);
                $updatepho = update("patient_history_obser",$setvalue,$wherecon,$execonn);
            } else {
                $fields = "appoitment_id,patient_id,history,observation,consulteddata,created_date";
                $values = ":appoitment_id,:patient_id,:history,:observation,:consulteddata,:created_date";
                $execon = array(
                    ":appoitment_id" => $appid,
                    ":patient_id" => $patientid,
                    ":history" => $phistory,
                    ":observation" => $pobservation,
                    ":consulteddata" => $consulteddata,
                    ":created_date" => date("Y-m-d H:i:s"),
                );
                $savepho = save("patient_history_obser",$fields,$values,$execon);
            }
            
            $result = array("Status"=>"ok","savepho"=>$savepho,"updatepho"=>$updatepho);
            echo json_encode($result);
        }
        
        if(isset($postdata->conssavenew))
        {
            $phistory = isset($postdata->phistory) ? $postdata->phistory : "";
            $pobservation = isset($postdata->pobservation) ? $postdata->pobservation : "";
            $pid = $postdata->pid;
            $appid = $postdata->appid;
            
            $findpid = find('first','patient','*',"where unique_pid = '".$pid."' ",array());
            $patientid = $findpid['patient_id'];
            
            $findalreadyadded = find("first","patient_history_obser","*","where appoitment_id = '".$appid."' and patient_id = '".$patientid."' ",array());
            
            if($findalreadyadded){
                $setvalue = "history=:history,observation=:observation";
                $wherecon = "where appoitment_id = '".$appid."' and patient_id = '".$patientid."' ";
                $execon = array(
                    ":history"=>$phistory,
                    ":observation"=>$pobservation,
                );
                $updatepho = update("patient_history_obser",$setvalue,$wherecon,$execon);
                
                $result = array("Status"=>"ok","updatepho"=>$updatepho);
                echo json_encode($result);
            } else{
                $fields = "appoitment_id,patient_id,history,observation,created_date";
                $values = ":appoitment_id,:patient_id,:history,:observation,:created_date";
                $exe = array(
                    ":appoitment_id" => $appid,
                    ":patient_id" => $patientid,
                    ":history" => $phistory,
                    ":observation" => $pobservation,
                    ":created_date" => date("Y-m-d H:i:s"),
                );
                $savepho = save("patient_history_obser",$fields,$values,$exe);
                
                $result = array("Status"=>"ok","savepho"=>$savepho);
                echo json_encode($result);
            }
        }
        
        if(isset($postdata->saveortoneuro))
        {
            $appid = $postdata->appid;
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $patientid = $findpid['patient_id'];
            $saveorthoneuro = 0;
            $updateon = false;
            
            $findalreadyon = find("all","orthoneurodata","*","where patient_id = '".$patientid."' and appointment_id = '".$appid."' ",array());
            if($findalreadyon){
                foreach($postdata as $k=>$v){
                    $findalreadykey = find("first","orthoneurodata","*","where patient_id = '".$patientid."' and appointment_id = '".$appid."' and meta_key = '".$k."' ",array());
                    if($findalreadykey){
                        $setvalue = "meta_value=:meta_value";
                        $where = "where patient_id = '".$patientid."' and appointment_id = '".$appid."' and meta_key = '".$k."' ";
                        $execon = array(":meta_value"=>$v);
                        $updateon = update("orthoneurodata",$setvalue,$where,$execon);
                    } else {
                        if($k == "saveortoneuro" || $k == "appid" || $k == "puid"){}else{
                            $fields = "patient_id,appointment_id,meta_key,meta_value,created_date";
                            $values = ":patient_id,:appointment_id,:meta_key,:meta_value,:created_date";
                            $exe = array(
                                    ":patient_id"=>$patientid,
                                    ":appointment_id"=>$appid,
                                    ":meta_key"=>$k,
                                    ":meta_value"=>$v,
                                    ":created_date"=>date("Y-m-d H:i:s"),
                                );
                            $saveorthoneuro = save("orthoneurodata",$fields,$values,$exe);
                        }
                    }
                }
            } else {
                foreach($postdata as $k=>$v){
                    if($k == "saveortoneuro" || $k == "appid" || $k == "puid"){}else{
                        $fields = "patient_id,appointment_id,meta_key,meta_value,created_date";
                        $values = ":patient_id,:appointment_id,:meta_key,:meta_value,:created_date";
                        $exe = array(
                                ":patient_id"=>$patientid,
                                ":appointment_id"=>$appid,
                                ":meta_key"=>$k,
                                ":meta_value"=>$v,
                                ":created_date"=>date("Y-m-d H:i:s"),
                            );
                        $saveorthoneuro = save("orthoneurodata",$fields,$values,$exe);
                    }
                }
            }
            
            
            $result = array("Status"=>"ok","saveorthoneuro"=>$saveorthoneuro,"updateon"=>$updateon);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchconsdata))
        {
            $pid = $postdata->pid;
            $appid = $postdata->appid;
            
            $findpid = find('first','patient','*',"where unique_pid = '".$pid."' ",array());
            $patientid = $findpid['patient_id'];
            
            $findconsulteddata = find("first","patient_history_obser","*","where patient_id = '".$patientid."' and appoitment_id = '".$appid."' ",array());
            
            $findappdetails = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            
            $findphodata = find("first","patient_history_obser","*","where appoitment_id = '".$appid."' and patient_id = '".$patientid."' ",array());
            
            $result = array("Status"=>"ok","findphodata"=>$findphodata,"findappdetails"=>$findappdetails,"findconsulteddata"=>$findconsulteddata);
            echo json_encode($result);
        }
        
    }
    ?>
