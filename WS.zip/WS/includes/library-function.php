<?php
if(isset($_SESSION["user_id"]))
{
	 $user_id = $_SESSION["user_id"];
}

function savenotification($sfi,$sti,$sfu,$stu,$heading,$content)
{
    $fields = "sent_from_id,sent_to_id,sent_from_user,sent_to_user,noti_heading,noti_content,is_viewed,is_read,created_date";
    $values = ":sent_from_id,:sent_to_id,:sent_from_user,:sent_to_user,:noti_heading,:noti_content,:is_viewed,:is_read,:created_date";
    $exe = array(
                ":sent_from_id"=>$sfi,
                ":sent_to_id"=>$sti,
                ":sent_from_user"=>$sfu,
                ":sent_to_user"=>$stu,
                ":noti_heading"=>$heading,
                ":noti_content"=>$content,
                ":is_viewed"=>"N",
                ":is_read"=>"N",
                ":created_date"=>date("Y-m-d H:i:s")
            );

    $savenotification = save("notifications",$fields,$values,$exe);
    return $savenotification;
}


?>