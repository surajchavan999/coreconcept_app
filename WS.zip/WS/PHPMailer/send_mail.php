<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

include("../init.php");
    
    // $to = "hitesh.zhambare@tdtl.world";
    $subject = "Testing Subject";//$_POST["subject"];
    $name = "Hitesh Zhambare";//$_POST["fullname"];
    $fromname = "TDTL";//$_POST["fromname"];
    $message = "Testing";
    
    $filename = $_POST['filename'];
    $findpidemail = json_decode($_POST['findpidemail']);
    $to = $findpidemail->email;
    
    // $nomPdf = $_FILES['pdfile']['name'];
    
    // $uploaddirectory = "../uploads/invoices/";
    // $totalfilepath = "https://clinic.coreconcept.in/ws/uploads/invoices/".$_FILES['pdfile']['name'];
    // move_uploaded_file($_FILES['pdfile']['tmp_name'],$uploaddirectory.$_FILES['pdfile']['name']);
    // print_r($_POST);
    
    
// print_r($_POST);exit();
    // // $b64file = $_POST['hii'];
    // $b64file = $_POST['pdfData'];
    // // // print_r($b64file);exit();
    // // $nomPdf = "invoice.pdf";
    // // // $nomPdf = (string)$nomPdf;
    // $b64 = explode("base64,",$b64file)[1];
    // // $decodPdf= base64_decode($b64file,true);
    // // file_put_contents($nomPdf, $decodPdf);
    // // print_r($b64file);
    // // sleep(20);
    
    

# Decode the Base64 string, making sure that it contains only valid characters
// $bin = base64_decode($b64, true);

# Perform a basic validation to make sure that the result is a valid PDF file
# Be aware! The magic number (file signature) is not 100% reliable solution to validate PDF files
# Moreover, if you get Base64 from an untrusted source, you must sanitize the PDF contents
// if (strpos($bin, '%PDF') !== 0) {
//   throw new Exception('Missing the PDF file signature');
// }

// # Write the PDF contents to a local file
// file_put_contents('file.pdf', $bin);
    
    
    
    // exit();
    
    // $pdf = fopen ('test.pdf','w');
    // fwrite ($pdf,$decodPdf);
    // fclose ($pdf);
    
    
    // exit();
    
    require 'PHPMailerAutoload.php';
    $mail = new PHPMailer(); // create a new object
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 2; // debugging: 1 = errors and messages, 2 = messages only
    $mail->Host = "smtp.hostinger.com";
    $mail->Port = 465;
    $mail->SMTPAuth = true; // authentication enabled
    $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
    $mail->IsHTML(true);
    $mail->Username = "coreconcept@tdtl.info";
    $mail->Password = "Coreconcept@2023";
    $mail->SetFrom("coreconcept@tdtl.info",$fromname);
    $mail->Subject = $subject;
    $mail->Body = $message;
    $mail->AddAddress($to,$name);
    // $mail->AddAddress("ujwal.patil@tdtl.world","Ujwal Patil");
    
    // $filename = $_POST['filename'];
    // $fileattach = "../uploads/proposalfiles/".$filename.".pdf"; // full path
    $mail->AddAttachment("../uploads/invoicefiles/".$filename);

    //$mail->addcc('sunnicse@gmail.com');
    if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message has been sent";
    }
?>