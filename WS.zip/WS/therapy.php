<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));
		
		if(isset($postdata->fetchtreatmian))
		{
		    $puid = $postdata->puid;
		    $appid = $postdata->appid;
		    $treatid = $postdata->treatid;
		    $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
		    
		    $findvtdatam = find("first","treatments","*","where treatment_id = '".$treatid."'",array());
		    
		    $findtherypy = find("first","therapytreatments","*","where treatment_id = '".$treatid."' and patient_id = '".$findpid['patient_id']."' ",array());
		    
		    $findappdetails = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
		    
		    $result = array("Status"=>"ok","findvtdatam"=>$findvtdatam,"findtherypy"=>$findtherypy,"findpid"=>$findpid,"findappdetails"=>$findappdetails);
            echo json_encode($result);
		}
		
		if(isset($postdata->fetchviewtreatdata))
		{
		    $puid = $postdata->puid;
		    $appid = $postdata->appid;
		    $treatid = $postdata->treatid;
		    $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
		    $findappdetails = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
		    
		    $findvtdata = find("first","treatments","*","where treatment_id = '".$treatid."'",array());
		    
		    $findtherypy = find("first","therapytreatments","*","where treatment_id = '".$treatid."' and patient_id = '".$findpid['patient_id']."' ",array());
	        
	        $result = array("Status"=>"ok","findvtdata"=>$findvtdata,"findtherypy"=>$findtherypy,"findpid"=>$findpid,"findappdetails"=>$findappdetails);
            echo json_encode($result);
		}
		
		if(isset($postdata->fetchtherpy))
		{
		    $findtherypy = find("first","therapytreatments","*","where 1 ORDER BY therapytreat_id DESC",array());
		
    		$result = array("Status"=>"ok","findtherypy"=>$findtherypy);
            echo json_encode($result);
		}
		
		if(isset($postdata->savetherpy))
		{
		    $puid = $postdata->puid;
		    $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $treatment_id = $postdata->treatment_id;
		    $therapydata = json_encode($postdata->therapydata);
		    
		    $findalreadyadded = find("first","therapytreatments","*","where patient_id = '".$findpid['patient_id']."' and treatment_id = '".$treatment_id."' ",array());
		    if($puid != "" && $treatment_id != "")
		    {
    		    if($findalreadyadded)
    		    {
    		        $setvalue = "therapydata=:therapydata";
    		        $wherecon = "where patient_id = '".$findpid['patient_id']."' and treatment_id = '".$treatment_id."' ";
    		        $exeu = array(":therapydata"=>$therapydata);
    		        
    		        $updatetp = update("therapytreatments",$setvalue,$wherecon,$exeu);
    		        
    		    } else {
                    $fields = "patient_id,treatment_id,therapydata,updated_date";
                    $values = ":patient_id,:treatment_id,:therapydata,:updated_date";
                    $exe = array(
                            ":patient_id"=> $findpid['patient_id'],
                            ":treatment_id"=> $treatment_id,
                            ":therapydata"=> $therapydata,
                            ":updated_date"=> date("Y-m-d H:i:s"),
                        );
                        
                    $savetherapy = save("therapytreatments",$fields,$values,$exe);
    		    }
		    }
		    
    		$result = array("Status"=>"ok","savetherapy"=>$savetherapy,"updatetp"=>$updatetp);
            echo json_encode($result);
		}
	}
?>