<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->fetchcommdata))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());

            $findallcommunication = find("all","communication","*","where patient_id = '".$findpid['patient_id']."' ",array());

            $result = array("Status"=>"ok","findpdetail"=>$findpid,"findallcommunication"=>$findallcommunication);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchcommdatamain))
        {
            $user = $postdata->user;
            $userid = $postdata->userid;
            $findallcommunication = [];
            if($user == "Patient"){
                $findallcommunication = find("all","communication","*","where patient_id = '".$userid."' ",array());
            }
            
            $result = array("Status"=>"ok","findallcommunication"=>$findallcommunication);
	        echo json_encode($result);
        }

        if(isset($_POST['addcommmessagemain']))
        {
            $commessage = $_POST['commessage'];
            $luserid = $_POST['luserid'];
            $luser = $_POST['luser'];
            
            
            // $commfile = $_FILES['commfile'];
            $commfilename = (isset($_FILES['commfile'])) ? $_FILES['commfile']['name'] : "";
            
            $fields = "patient_id,luserid,luser,commessage,commfile,is_view,created_at";
            $values = ":patient_id,:luserid,:luser,:commessage,:commfile,:is_view,:created_at";
            
            $exe = array(
                ":patient_id" => $luserid,
                ":luserid" => $luserid,
                ":luser" => $luser,
                ":commessage" => $commessage,
                ":commfile" => $commfilename,
                ":is_view" => "N",
                ":created_at" => date("Y-m-d H:i:s"),
            );
            $savecommunicationmain = save("communication",$fields,$values,$exe);
            
            if($savecommunicationmain){
                if(isset($_FILES['commfile'])){
                    $file_ext = strtolower(explode('.',$_FILES['commfile']['name'])[1]);
                    $filename = explode('.',$_FILES['commfile']['name'])[0];
                    $tempname = $_FILES['commfile']['tmp_name'];
                    $targetwithfile = "uploads/communicationfiles/".$filename."_".$savecommunicationmain.".".$file_ext;
                    move_uploaded_file($tempname,$targetwithfile);
                }
            }
            
            
            $result = array("Status"=>"ok","savecommunicationmain"=>$savecommunicationmain);
	        echo json_encode($result);
        }
        
        if(isset($_POST['addcommmessage']))
        {
            $commessage = $_POST['commessage'];
            $puid = $_POST['puid'];
            $luserid = $_POST['luserid'];
            $luser = $_POST['luser'];
            // $commfile = $_FILES['commfile'];
            $commfilename = (isset($_FILES['commfile'])) ? $_FILES['commfile']['name'] : "";

            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());

            $fields = "patient_id,luserid,luser,commessage,commfile,is_view,created_at";
            $values = ":patient_id,:luserid,:luser,:commessage,:commfile,:is_view,:created_at";
            $exe = array(
                ":patient_id" => $findpid['patient_id'],
                ":luserid" => $luserid,
                ":luser" => $luser,
                ":commessage" => $commessage,
                ":commfile" => $commfilename,
                ":is_view" => "N",
                ":created_at" => date("Y-m-d H:i:s"),
            );
            $savecommunication = save("communication",$fields,$values,$exe);
            
            if($savecommunication){
                if(isset($_FILES['commfile'])){
                    $file_ext = strtolower(explode('.',$_FILES['commfile']['name'])[1]);
                    $filename = explode('.',$_FILES['commfile']['name'])[0];
                    $tempname = $_FILES['commfile']['tmp_name'];
                    $targetwithfile = "uploads/communicationfiles/".$filename."_".$savecommunication.".".$file_ext;
                    move_uploaded_file($tempname,$targetwithfile);
                }
            }

            $result = array("Status"=>"ok","savecommunication"=>$savecommunication);
	        echo json_encode($result);
        }
    }
?>