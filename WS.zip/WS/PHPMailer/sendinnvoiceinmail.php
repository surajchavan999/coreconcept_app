<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

include("../init.php");
    
    $filename = $_POST['filename'];
    $findpidemail = json_decode($_POST['findpidemail']);
    $to = $findpidemail->email;
    $name = $findpidemail->patient_name;
    
    $invoiceNumber = str_replace(["Invoice_", ".pdf"], '', $filename);
    
    
    // $to = "hitesh.zhambare@tdtl.world";
    $subject = " Invoice from CoreConcept - $invoiceNumber";//$_POST["subject"];
    $fromname = "CoreConcept";//$_POST["fromname"];
    $message = "
                    Dear <b>".$name."</b>,
                    <br><br>
                    We hope this email finds you in good health. Thank you for choosing CoreConcept Clinic for your healthcare needs. Attached to this email, you will find the invoice for the services provided during your recent visit.
                    <br><br>
                    Please take a moment to review the invoice and let us know if you have any questions or concerns.
                    <br><br>
                    Thank you for choosing CoreConcept. We look forward to seeing you soon.
                    <br><br>
                    Best regards,<br>
                    CoreConcept Support Team
                ";
    
    // print_r($message);
    // exit();
    
    require 'PHPMailerAutoload.php';
    $mail = new PHPMailer(); // create a new object
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 2; // debugging: 1 = errors and messages, 2 = messages only
    $mail->Host = "smtp.hostinger.com";
    $mail->Port = 465;
    $mail->SMTPAuth = true; // authentication enabled
    $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
    $mail->IsHTML(true);
    $mail->Username = "coreconcept@tdtl.info";
    $mail->Password = "Coreconcept@2023";
    $mail->SetFrom("coreconcept@tdtl.info",$fromname);
    $mail->Subject = $subject;
    $mail->Body = $message;
    $mail->AddAddress($to,$name);
    
    $mail->AddAttachment("../uploads/invoicefiles/".$filename);
    
    // $filename = $_POST['filename'];
    // $fileattach = "../uploads/proposalfiles/".$filename.".pdf"; // full path
    // $mail->AddAttachment($fileattach);

    //$mail->addcc('sunnicse@gmail.com');
    if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message has been sent";
    }
?>