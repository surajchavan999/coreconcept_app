<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->fetchroutespdata))
        {
            $findallpid = find("all","patient","*","where 1",array());
            
            // foreach($findallpid as $k=$v){

            // }
            $result = array("Status"=>"ok","findallpid"=>$findallpid);
	        echo json_encode($result);
        }
    }
?>