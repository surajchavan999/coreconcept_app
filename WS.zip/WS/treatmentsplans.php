<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));
		
        if(isset($postdata->submitconsent))
        {
            $puid = $postdata->puid;
            $imgcaptured = isset($postdata->imgcaptured) ? $postdata->imgcaptured : "" ;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $saveconsent = 0;
            
            $fields = "patient_id,signed,created_date";
            $values = ":patient_id,:signed,:created_date";
            $exe = array(
                ":patient_id"=>$findpid['patient_id'],
                ":signed"=>$imgcaptured,
                ":created_date"=>date("Y-m-d H:i:s"),
                );
            $saveconsent = save("consent_form",$fields,$values,$exe);
            
            $result = array("Status"=>"ok","saveconsent"=>$saveconsent);
	        echo json_encode($result);
        }
        
        if(isset($postdata->checkconsent))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            
            $checkconsent = find("first","consent_form","*","where patient_id = '".$findpid['patient_id']."' ",array());
            if($checkconsent){ if($checkconsent['signed'] != ""){ $consentsigned = true; } else{$consentsigned = false;} }else{$consentsigned = false;}
            
            $result = array("Status"=>"ok","checkconsent"=>$checkconsent,"consentsigned"=>$consentsigned);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchapptreat))
        {
            $appid = $postdata->appid;
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            
            $findapptreat = find("all","treatments","*","where patient_id = '".$findpid['patient_id']."' and appointment_id = '".$appid."' ",array());
            
            $result = array("Status"=>"ok","findapptreat"=>$findapptreat);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchtpdata))
        {
            $puid = $postdata->puid;

            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());

            // $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id";
            // $findtpapp = find('all',$tableappoit,'*, appointment.status as astatus',"where patient_id = '".$findpid['patient_id']."' ",array());
            $table = "treatments inner join procedures on treatments.procedure_id=procedures.procedure_id";
            $findalltreatments = find("all",$table,"*","where treatments.patient_id = '".$findpid['patient_id']."' ",array());
            
            $findallapp = find("all","appointment","*","where patient_id = '".$findpid['patient_id']."' and dept_id = '1' and status = 'A' order by schedule_date DESC ",array());
            foreach($findallapp as $k=>$v){
                $findapptreat = find("all",$table,"*","where patient_id = '".$v['patient_id']."' and appointment_id = '".$v['appointment_id']."' ",array());
                // $findapptreat = find("all","treatments","*","where patient_id = '".$v['patient_id']."' and appointment_id = '".$v['appointment_id']."' ",array());
                $temparr = array("treatment"=>$findapptreat);$findallapp[$k] = array_merge($temparr,$findallapp[$k]);
                // else{ $temparr = array("treatment"=>$findapptreat); $findallapp[$k] = array_merge($temparr,$findallapp[$k]); }
            }

            $result = array("Status"=>"ok","findalltreatments"=>$findalltreatments,"findallapp"=>$findallapp,"findpid"=>$findpid);
	        echo json_encode($result);
        }

        if(isset($postdata->addprocedure))
        {
            $proceudrename = $postdata->proceudrename;
            $procedureprice = $postdata->procedureprice;

            $fields = "procedure_name,procedure_price,created_date";
            $values = ":procedure_name,:procedure_price,:created_date";
            $exep = array(
                ":procedure_name"=>$proceudrename,
                ":procedure_price"=>$procedureprice,
                ":created_date"=>date("Y-m-d H:i:s")
            );

            $saveprocedure = save("procedures",$fields,$values,$exep);

            $result = array("Status"=>"ok","saveprocedure"=>$saveprocedure);
	        echo json_encode($result);
        }
        
        if(isset($postdata->deletetherapy))
        {
            $treatment_id  = $postdata->treatment_id;
            
            $deletetherapy = delete("treatments","where treatment_id = '".$treatment_id."' ",array());
            $result = array("Status"=>"ok","deletetherapy"=>$deletetherapy);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchallprocedure))
        {
            $puid = $postdata->puid;
            $appid = $postdata->appid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $patientid = $findpid['patient_id'];
            
            $findqllprocedure = find("all","procedures","*","where 1",array());
            
            $table = "treatments inner join procedures on treatments.procedure_id=procedures.procedure_id";
            $findapptreat = find("all",$table,"*","where patient_id = '".$patientid."' and appointment_id = '".$appid."' ",array());
            
            $result = array("Status"=>"ok","findqllprocedure"=>$findqllprocedure,"findapptreat"=>$findapptreat);
            echo json_encode($result);
        }

        if(isset($postdata->addtreatment))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $appid = $postdata->appid;
            
            $treatrowsall = $postdata->treatrowsall;
            // print_r($treatrowsall);
            foreach($treatrowsall as $k=>$v){
                $procedureid = $v->treatid;
                $therapyname = $v->therapyname;
                $countdays = isset($v->noofdays) ? $v->noofdays : "";
                $proprice = isset($v->priceou) ? $v->priceou : "";
                $tnotes = isset($v->tnotes) ? $v->tnotes : "";
                $proqty = 1;
                
                $fieldst = "patient_id,appointment_id,procedure_id,tnotes,quantity,tcost,amount,discount,discount_type,doctor_id,fromdate,todate,totaldays,created_at";
                $valuest = ":patient_id,:appointment_id,:procedure_id,:tnotes,:quantity,:tcost,:amount,:discount,:discount_type,:doctor_id,:fromdate,:todate,:totaldays,:created_at";
                
                $exet = array(
                    ":patient_id" => $findpid['patient_id'],
                    ":appointment_id"=>$appid,
                    ":procedure_id" => $procedureid,
                    ":tnotes" => $tnotes,
                    ":quantity" => "1",
                    ":tcost" =>  $proprice,
                    ":amount" => $proqty * $proprice,
                    ":discount" => "0",
                    ":discount_type" => "NUMBER",
                    ":doctor_id" => "0",
                    ":fromdate" => "",
                    ":todate" => "",
                    ":totaldays" => $countdays,
                    ":created_at" => date("Y-m-d H:i:s"),
                );
                $savetreatment = save("treatments",$fieldst,$valuest,$exet);
            }
            // $procedureid = $postdata->procedureid;
            // $tnotes = (isset($postdata->tnotes)) ? $postdata->tnotes : "";
            // $proqty = $postdata->proqty;
            // $proprice = $postdata->proprice;
            // $discountval = $postdata->discountval;
            // $distype = $postdata->distype;
            // $totalval = $postdata->totalval;
            // $docotrid = $postdata->docotrid;
            // $fromdate = $postdata->fromdate;
            // $todate = $postdata->todate;
            // $countdays = $postdata->countdays;

            // $fieldst = "patient_id,appointment_id,procedure_id,tnotes,quantity,tcost,amount,discount,discount_type,doctor_id,fromdate,todate,totaldays,created_at";
            // $valuest = ":patient_id,:appointment_id,:procedure_id,:tnotes,:quantity,:tcost,:amount,:discount,:discount_type,:doctor_id,:fromdate,:todate,:totaldays,:created_at";
            // $exet = array(
            //     ":patient_id" => $findpid['patient_id'],
            //     ":appointment_id"=>$appid,
            //     ":procedure_id" => $procedureid,
            //     ":tnotes" => $tnotes,
            //     ":quantity" => $proqty,
            //     ":tcost" =>  $proprice,
            //     ":amount" => $proqty * $proprice,
            //     ":discount" => $discountval,
            //     ":discount_type" => $distype,
            //     ":doctor_id" => $docotrid,
            //     ":fromdate" => $fromdate,
            //     ":todate" => $todate,
            //     ":totaldays" => $countdays,
            //     ":created_at" => date("Y-m-d H:i:s"),
            // );
            // $savetreatment = save("treatments",$fieldst,$valuest,$exet);






            // if($savetreatment){

            //     $findproname = find("first","procedures","*","where procedure_id = '".$procedureid."' ",array());

            //     function findinnvoiceno(){
            //         $ino = "INV".rand(1,9999);
            //         $findinvono = find("first","invoices","*","where invoice_number = '".$ino."' ",array());
            //         if($findinvono){
            //             findinnvoiceno();
            //         } else {
            //             return $ino;
            //         }
            //     }
                
            //     $findinnvoicenumber = find("first","invoices","*","where appointment_id = '".$appid."' ",array());
            //     if($findinnvoicenumber){ $invoicenumber = $findinnvoicenumber['invoice_number']; }else { $invoicenumber = findinnvoiceno(); }

            //     $fields = "invoice_number,appointment_id,patient_id,doctor_id,treatment_name,dept_id,unit_cost,quantity,discount,discount_type,cancelled,created_at";
            //     $values = ":invoice_number,:appointment_id,:patient_id,:doctor_id,:treatment_name,:dept_id,:unit_cost,:quantity,:discount,:discount_type,:cancelled,:created_at";
            //     $exein = array(
            //         ":invoice_number" => $invoicenumber,
            //         ":appointment_id" => $appid,
            //         ":patient_id" => $findpid['patient_id'],
            //         ":doctor_id" => 0,
            //         ":treatment_name" => $findproname['procedure_name'],
            //         ":dept_id" => "0",
            //         ":unit_cost" => $proprice,
            //         ":quantity" => $proqty,
            //         ":discount" => $discountval,
            //         ":discount_type" => $distype,
            //         ":cancelled" => 0 ,
            //         ":created_at" => date("Y-m-d H:i:s")
            //     );
            //     $saveinvoice = save("invoices",$fields,$values,$exein);
            // }

            $result = array("Status"=>"ok","savetreatment"=>$savetreatment);
            echo json_encode($result);
        }
        
        if(isset($postdata->finddname))
        {
            $did = $postdata->did;
            $finddname = find("first","doctor","*","where doctor_id = '".$did."' ",array());

            $result = array("Status"=>"ok","finddname"=>$finddname);
            echo json_encode($result);
        }

        if(isset($postdata->fetchdatatpt))
        {
            $user = $postdata->user;
            $userid = $postdata->userid;
            $findallpatient = find("all","patient","*","where 1 order by patient_id DESC",array());
            if($user == "Patient")
            {
                $findallpatient = find("all","patient","*","where patient_id = '$userid' ",array());
            }

            $result = array("Status"=>"ok","findallpatient"=>$findallpatient);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchviewtp))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            
            $table = "treatments inner join procedures on treatments.procedure_id=procedures.procedure_id";
            $findalltreatments = find("all",$table,"*","where treatments.patient_id = '".$findpid['patient_id']."' ",array());
            
            $findallapp = find("all","appointment","*","where patient_id = '".$findpid['patient_id']."' and dept_id = '1' and status = 'A' ",array());
            foreach($findallapp as $k=>$v){
                $findapptreat = find("all",$table,"*","where patient_id = '".$v['patient_id']."' and appointment_id = '".$v['appointment_id']."' ",array());
                // $findapptreat = find("all","treatments","*","where patient_id = '".$v['patient_id']."' and appointment_id = '".$v['appointment_id']."' ",array());
                $temparr = array("treatment"=>$findapptreat);$findallapp[$k] = array_merge($temparr,$findallapp[$k]);
                // else{ $temparr = array("treatment"=>$findapptreat); $findallapp[$k] = array_merge($temparr,$findallapp[$k]); }
            }
            
            $result = array("Status"=>"ok","findalltreatments"=>$findalltreatments,"findpid"=>$findpid,"findallapp"=>$findallapp);
            echo json_encode($result);
        }
        
        if(isset($postdata->finddepttype))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $pid = $findpid['patient_id'];
            $Physiotherapy = false;
            $Dietitian = false;
            
            $table = "appointment inner join department on appointment.dept_id=department.dept_id";
            $finddeptpyso = find("all",$table,"*","where appointment.patient_id = '".$pid."' and  department.dept_name = 'Physiotherapy' and appointment.status = 'A' ",array());
            $finddeptdiet = find("all",$table,"*","where appointment.patient_id = '".$pid."' and  department.dept_name = 'Dietitian' and appointment.status = 'A' ",array());
            if($finddeptpyso){
                $Physiotherapy = true;
            }
            if($finddeptdiet){
                $Dietitian = true;
            }
            
            $result = array("Status"=>"ok","Physiotherapy"=>$Physiotherapy,"Dietitian"=>$Dietitian);
            echo json_encode($result);
        }

        if(isset($_POST['adddietplan']))
        {
            // $puid = $_POST['puid'];
            // $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            // $pid = $findpid['patient_id'];
            $dietname = $_POST['dietname'];
            $dietprice = $_POST['dietprice'];

            $file_ext = strtolower(explode('.',$_FILES['imagefile']['name'])[1]);
            $imagefile = $_FILES['imagefile']['name'];
            $tempname = $_FILES['imagefile']['tmp_name'];
            $targetwithfile = "uploads/dietplans/".$imagefile;
            move_uploaded_file($tempname,$targetwithfile);

            $fields = "dietname,dietprice,dietfile,status,created_date";
            $values = ":dietname,:dietprice,:dietfile,:status,:created_date";
            $exe = array(
                ":dietname" => $dietname,
                ":dietprice" => $dietprice,
                ":dietfile" => $targetwithfile,
                ":status" => "Y",
                ":created_date" => date("Y-m-d H:i:s"),
            );

            $savedietplan = save("dietprocedures",$fields,$values,$exe);
            
            $result = array("Status"=>"ok","savedietplan"=>$savedietplan);
            echo json_encode($result);
        }

        if(isset($postdata->fetchdietplan))
        {
            $finddietplan = find("all","dietprocedures","*","where 1",array());

            $result = array("Status"=>"ok","finddietplan"=>$finddietplan);
            echo json_encode($result);
        }

        if(isset($postdata->savepdp))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $pid = $findpid['patient_id'];
            $fromdatedp = $postdata->fromdatedp;
            $todatedp = $postdata->todatedp;
            $dietproid = $postdata->dietproid;
            $docotrid = $postdata->docotrid;
            $discountvaldp = $postdata->discountvaldp;
            $distypedp = $postdata->distypedp;
            $proditeprice = $postdata->proditeprice;

            $fields = "dietproid,fromdate,todate,patient_id,dis_type,discount,doctor_id,status,created_date";
            $values = ":dietproid,:fromdate,:todate,:patient_id,:dis_type,:discount,:doctor_id,:status,:created_date";
            $exe  = array(
                ":dietproid" => $dietproid,
                ":fromdate" => $fromdatedp,
                ":todate" => $todatedp,
                ":patient_id" => $pid,
                ":dis_type" => $distypedp,
                ":discount" => $discountvaldp,
                ":doctor_id" => $docotrid,
                ":status" => "Y",
                ":created_date" => date("Y-m-d H:i:s"),
            );

            $savepdietplan = save("diettreatment",$fields,$values,$exe);

            if($savepdietplan)
            {
                $finddietproname = find("first","dietprocedures","*","where dietpid = '".$dietproid."' ",array());

                function findinnvoiceno(){
                    $ino = "INV".rand(1,9999);
                    $findinvono = find("first","invoices","*","where invoice_number = '".$ino."' ",array());
                    if($findinvono){
                        findinnvoiceno();
                    } else {
                        return $ino;
                    }
                }

                $fields = "invoice_number,patient_id,doctor_id,treatment_name,dept_id,unit_cost,quantity,discount,discount_type,cancelled,created_at";
                $values = ":invoice_number,:patient_id,:doctor_id,:treatment_name,:dept_id,:unit_cost,:quantity,:discount,:discount_type,:cancelled,:created_at";
                $exein = array(
                    ":invoice_number" => findinnvoiceno(),
                    ":patient_id" => $pid,
                    ":doctor_id" => "0",
                    ":treatment_name" => $finddietproname['dietname'],
                    ":dept_id" => "0",
                    ":unit_cost" => $proditeprice,
                    ":quantity" => "1",
                    ":discount" => $discountvaldp,
                    ":discount_type" => $distypedp,
                    ":cancelled" => "0",
                    ":created_at" => date("Y-m-d H:i:s")
                );
                $saveinvoice = save("invoices",$fields,$values,$exein);
            }

            $result = array("Status"=>"ok","savepdietplan"=>$savepdietplan);
            echo json_encode($result);
        }

        if(isset($postdata->fetchdpdata))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $pid = $findpid['patient_id'];
            
            $findpatientappoint = find("all","appointment","*","where patient_id = '".$pid."' and status = 'A' and dept_id = '2' ",array());
            
            $table = "diettreatment inner join dietprocedures on diettreatment.dietproid=dietprocedures.dietpid";
            $findalldiettreat = find("all",$table,"*, diettreatment.created_date as dtdate","where patient_id = '".$pid."' ",array());
            
            $result = array("Status"=>"ok","findpatientappoint"=>$findpatientappoint,"findalldiettreat"=>$findalldiettreat);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchdietplandata))
        {
            $puid = $postdata->puid;
            $appid = $postdata->appid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $pid = $findpid['patient_id'];
            
            $finddietplan = find("first","dietplanallocate","*","where patient_id = '".$pid."' and appointment_id = '".$appid."' ",array());
            
            $result = array("Status"=>"ok","finddietplan"=>$finddietplan,"findpid"=>$findpid);
            echo json_encode($result);
        }
        
        if(isset($postdata->savediteplan))
        {
            $rows = json_encode($postdata->rows);
            $anthropometric = json_encode($postdata->anthropometric);
            $puid = $postdata->puid;
            $appid = $postdata->appid;
            $notes = $postdata->notes;
            $fromdate = $postdata->fromdate;
            $todate = $postdata->todate;
            $daysmesaure = $postdata->daysmesaure;
            $fees = $postdata->fees;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $pid = $findpid['patient_id'];
            
            $findalreadyallocated = find("first","dietplanallocate","*","where patient_id = '".$pid."' and appointment_id = '".$appid."' ",array());
            if($findalreadyallocated){
                $setvalue = "fees=:fees,dietplandata=:dietplandata,notes=:notes,results_days=:results_days,fromdate=:fromdate,todate=:todate,mesurments=:mesurments";
                $wherecon = "where patient_id = '".$pid."' and appointment_id = '".$appid."' ";
                $execon = array(":fees"=>$fees,":dietplandata"=>$rows,":notes"=>$notes,":results_days"=>$daysmesaure,":fromdate"=>$fromdate,":todate"=>$todate,":mesurments"=>$anthropometric);
                $updatedietplan = update("dietplanallocate",$setvalue,$wherecon,$execon);
            } else {
                $fields = "patient_id,appointment_id,fees,dietplandata,notes,results_days,fromdate,todate,mesurments,created_date";
                $values = ":patient_id,:appointment_id,:fees,:dietplandata,:notes,:results_days,:fromdate,:todate,:mesurments,:created_date";
                $exe = array(
                        ":patient_id"=> $pid,
                        ":appointment_id"=> $appid,
                        ":fees" => $fees,
                        ":dietplandata"=> $rows,
                        ":notes"=> $notes,
                        ":results_days"=>$daysmesaure,
                        ":fromdate"=>$fromdate,
                        ":todate"=>$todate,
                        ":mesurments"=>$anthropometric,
                        ":created_date"=> date("Y-m-d H:i:s"),
                    );
                $savedietplan = save("dietplanallocate",$fields,$values,$exe);
            }
            
            if($savedietplan > 0 || $updatedietplan == true){
                function findinnvoiceno(){
                    $ino = "INV".rand(1,9999);
                    $findinvono = find("first","invoices","*","where invoice_number = '".$ino."' ",array());
                    if($findinvono){
                        findinnvoiceno();
                    } else {
                        return $ino;
                    }
                }
                $findappdetails = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
                $findinnvoicenumber = find("first","invoices","*","where appointment_id = '".$appid."' ",array());
                if($findinnvoicenumber){ $invoicenumber = $findinnvoicenumber['invoice_number']; }else { $invoicenumber = findinnvoiceno(); }
                $findinnvoiceupdate = find("first","invoices","*","where appointment_id = '".$appid."' and treatment_name = 'Diet Allocate' ",array());
                if($findinnvoiceupdate){
                    $setvalue = "unit_cost=:unit_cost";
                    $wherecon = "where invoices_id = '".$findinnvoiceupdate['invoices_id']."' ";
                    $execon = array(":unit_cost"=>$fees);
                    $updateinnvoice = update("invoices",$setvalue,$wherecon,$execon);
                } else{
                    $fields = "invoice_number,appointment_id,patient_id,doctor_id,treatment_name,dept_id,unit_cost,quantity,discount,discount_type,cancelled,status,showtp,created_at";
                    $values = ":invoice_number,:appointment_id,:patient_id,:doctor_id,:treatment_name,:dept_id,:unit_cost,:quantity,:discount,:discount_type,:cancelled,:status,:showtp,:created_at";
                    $exe = array(
                            ":invoice_number"=>$invoicenumber,
                            ":appointment_id"=>$appid,
                            ":patient_id"=>$pid,
                            ":doctor_id"=>$findappdetails['doc_id'],
                            ":treatment_name"=>"Diet Allocate",
                            ":dept_id"=>$findappdetails['dept_id'],
                            ":unit_cost"=>$fees,
                            ":quantity"=>"1",
                            ":discount"=>"0",
                            ":discount_type"=>"",
                            ":cancelled"=>"0",
                            ":status"=>"U",
                            ":showtp"=>"Y",
                            ":created_at"=>date("Y-m-d H:i:s"),
                        );
                    $saveinnvoice = save("invoices",$fields,$values,$exe);
                }
            }
            
            $result = array("Status"=>"ok","savedietplan"=>$savedietplan,"updatedietplan"=>$updatedietplan);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchdietplanmain))
        {

            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $pid = $findpid['patient_id'];

            $table = "diettreatment inner join dietprocedures on diettreatment.dietproid=dietprocedures.dietpid";

            $finddietplans = find("all",$table,"*, diettreatment.created_date as dtdate","where patient_id = '".$pid."' ",array());
            
            $findpatientappoint = find("all","appointment","*","where patient_id = '".$pid."' and status = 'A' and dept_id = '2' ",array());
            
            $result = array("Status"=>"ok","finddietplans"=>$finddietplans,"findpatientappoint"=>$findpatientappoint);
            echo json_encode($result);
        }
    }
?>