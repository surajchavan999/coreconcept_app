<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->deleteprescription))
        {
            $prescription_id = $postdata->prescription_id;
            
            $deleteprescription = delete("prescription","where prescription_id = '".$prescription_id."' ",array());
            $result = array("Status"=>"ok","deleteprescription"=>$deleteprescription);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchapppres))
        {
            $puid = $postdata->puid;

            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());

            $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id";
            $findpapp = find('all',$tableappoit,'*, appointment.status as astatus',"where patient_id = '".$findpid['patient_id']."' and appointment.status = 'A' order by schedule_date DESC ",array());

            $result = array("Status"=>"ok","findpapp"=>$findpapp);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchpreceptionmain))
        {
            $user = $postdata->user;
            $user_id = $postdata->user_id;
            
            $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id";
            if($user == "Patient"){
                $findpresmain = find('all',$tableappoit,'*, appointment.status as astatus',"where patient_id = '".$user_id."' and appointment.status = 'A' order by appointment.schedule_date DESC ",array());
            }
            if($user == "Admin"){
                $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id inner join patient on patient.patient_id=appointment.patient_id";
                $findpresmain = find('all',$tableappoit,'*, appointment.status as astatus',"where appointment.status = 'A' order by appointment.schedule_date DESC ",array());
            }
            if($user == "Doctor"){
                $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id inner join patient on patient.patient_id=appointment.patient_id";
                $findpresmain = find('all',$tableappoit,'*, appointment.status as astatus',"where appointment.status = 'A' order by appointment.schedule_date DESC ",array());
            }
            if($user == "Staff"){
                $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id inner join patient on patient.patient_id=appointment.patient_id";
                $findpresmain = find('all',$tableappoit,'*, appointment.status as astatus',"where appointment.status = 'A' order by appointment.schedule_date DESC ",array());
            }
            $result = array("Status"=>"ok","findpresmain"=>$findpresmain);
	        echo json_encode($result);
        }
        

        if(isset($postdata->adddrug))
        {
            $drugname = $postdata->drugname;
            $drugtype = $postdata->drugtype;
            $strengthnumber = (isset($postdata->strengthnumber)) ? $postdata->strengthnumber : "";
            $strengthtype = (isset($postdata->strengthtype)) ? $postdata->strengthtype : "";
            $instructions = (isset($postdata->instructions)) ? $postdata->instructions : "";

            $fields = "drug_name,drug_type,strength_number,strength,instruction,created_at";
            $values = ":drug_name,:drug_type,:strength_number,:strength,:instruction,:created_at";
            $exe = array(
                ":drug_name"=>$drugname,
                ":drug_type"=>$drugtype,
                ":strength_number"=>$strengthnumber,
                ":strength"=>$strengthtype,
                ":instruction"=>$instructions,
                ":created_at"=>date("Y-m-d H:i:s"),
            );
            $savedrug = save("drug",$fields,$values,$exe);

            $result = array("Status"=>"ok","savedrug"=>$savedrug);
	        echo json_encode($result);
        }

        if(isset($postdata->fetchalldrug))
        {
            $appid = $postdata->appid;
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());

            $findalldrug = find("all","drug","*","where 1",array());
            
            $findappdetails = find("first","appointment","*","where appointment_id = '".$appid."' ",array());

            $table = "prescription inner join drug on drug.drug_id=prescription.drug_id";
            $findallppresc = find("all",$table,"*, prescription.instruction as pinstruction","where prescription.patient_id = '".$findpid['patient_id']."' and prescription.appointment_id = '".$appid."' ",array());

            $result = array("Status"=>"ok","findalldrug"=>$findalldrug,"findallppresc"=>$findallppresc,"findpid"=>$findpid,"findappdetails"=>$findappdetails);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchviewprec))
        {
            $user = $postdata->user;
            $user_id = $postdata->user_id;
            $appid = $postdata->appid;
            
            $findappdetails = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            $patientid = $findappdetails['patient_id'];
            $findpdetails = find("first","patient","*","where patient_id = '".$patientid."' ",array());
            
            $table = "prescription inner join drug on drug.drug_id=prescription.drug_id";
            if($user == "Patient"){
                $findallviewppresc = find("all",$table,"* , prescription.instruction as pinstruction","where prescription.patient_id = '".$user_id."' and prescription.appointment_id = '".$appid."' ",array());
            }
            
            if($user == "Admin"){
                $table = "prescription inner join drug on drug.drug_id=prescription.drug_id";
                $findallviewppresc = find('all',$table,'* , prescription.instruction as pinstruction',"where prescription.appointment_id = '".$appid."' ",array());
            }
            if($user == "Doctor"){
                $table = "prescription inner join drug on drug.drug_id=prescription.drug_id";
                $findallviewppresc = find('all',$table,'* , prescription.instruction as pinstruction',"where prescription.appointment_id = '".$appid."' ",array());
            }
            if($user == "Staff"){
                $table = "prescription inner join drug on drug.drug_id=prescription.drug_id";
                $findallviewppresc = find('all',$table,'* , prescription.instruction as pinstruction',"where prescription.appointment_id = '".$appid."' ",array());
            }
            
            $result = array("Status"=>"ok","findallviewppresc"=>$findallviewppresc,"findpdetails"=>$findpdetails,"findappdetails"=>$findappdetails);
	        echo json_encode($result);
        }
        
        if(isset($postdata->saveprescription))
        {
            $strength = (isset($postdata->strength)) ? $postdata->strength : "";
            $strengthtype = (isset($postdata->strengthtype)) ? $postdata->strengthtype : "";
            $instruction = (isset($postdata->instruction)) ? $postdata->instruction : "";
            $duration = (isset($postdata->duration)) ? $postdata->duration : "" ;
            $durationtype = (isset($postdata->durationtype)) ? $postdata->durationtype : "" ;
            $morning = (isset($postdata->morning)) ? $postdata->morning : "" ;
            $noon = (isset($postdata->noon)) ? $postdata->noon : "" ;
            $night = (isset($postdata->night)) ? $postdata->night : "" ;
            $appid = (isset($postdata->appid)) ? $postdata->appid : "" ;
            $puid = (isset($postdata->puid)) ? $postdata->puid : "" ;
            $drugid = (isset($postdata->drugid)) ? $postdata->drugid : "" ;
            $beforeafterfood = (isset($postdata->beforeafterfood)) ? $postdata->beforeafterfood : "" ;
            $af = "0";
            $bf = "0";
            if($beforeafterfood == "after_food"){ $af = "1"; }
            if($beforeafterfood == "before_food"){ $bf = "1"; }

            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());

            $fields = "patient_id,appointment_id,drug_id,duration,duration_type,morning,noon,night,instruction,before_food,after_food,created_at";
            $values = ":patient_id,:appointment_id,:drug_id,:duration,:duration_type,:morning,:noon,:night,:instruction,:before_food,:after_food,:created_at";
            $exe = array(
                ":patient_id" => $findpid['patient_id'],
                ":appointment_id" => $appid,
                ":drug_id" => $drugid,
                ":duration" => $duration,
                ":duration_type" => $durationtype,
                ":morning" => $morning,
                ":noon" => $noon,
                ":night" => $night,
                ":instruction" => $instruction,
                ":before_food" => $bf,
                ":after_food" => $af,
                ":created_at" => date("Y-m-d H:i:s"),
            );

            $saveprescription = save("prescription",$fields,$values,$exe);

            $result = array("Status"=>"ok","saveprescription"=>$saveprescription);
            echo json_encode($result);
        }
    }
?>