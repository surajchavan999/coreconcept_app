<?php																																										

    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));
		
		
        if(isset($postdata->editstaff))
        {
            $staff_idedit = $postdata->staff_idedit;
            $staff_nameedit = $postdata->staff_nameedit;
            $staff_emailedit = $postdata->staff_emailedit;
            $mobile_numberedit = $postdata->mobile_numberedit;
            $roleedit = $postdata->roleedit;
            
            $updatestaff = update("staff",
                                "staff_name=:staff_name,staff_email=:staff_email,mobile_number=:mobile_number,role_id=:role_id",
                                "where staff_id = '".$staff_idedit."' ",
                                array(":staff_name"=>$staff_nameedit,":staff_email"=>$staff_emailedit,":mobile_number"=>$mobile_numberedit,":role_id"=>$roleedit)
                                );
            $result = array("Status"=>"ok","updatestaff"=>$updatestaff);
	        echo json_encode($result);
        }
        
        if(isset($postdata->changestatusstaff))
        {
            $staff_id = $postdata->staff_id;
            $status = $postdata->status;
            
            $updatedrstatus = update("staff","status=:status","where staff_id = '".$staff_id."' ",array(":status"=>$status));
            
            $result = array("Status"=>"ok","updatedrstatus"=>$updatedrstatus);
	        echo json_encode($result);
        }
		
        if(isset($postdata->deletepro))
        {
            $procedure_id = $postdata->procedure_id;
            
            $deletepro = delete("procedures","where procedure_id = '".$procedure_id."' ",array());
            
            $result = array("Status"=>"ok","deletepro"=>$deletepro);
	        echo json_encode($result);
        }
        
        if(isset($postdata->updatapord))
        {
            $upprocedure_id = $postdata->upprocedure_id;
            $proceudrenameedit = $postdata->proceudrenameedit;
            $procedurepriceedit = $postdata->procedurepriceedit;
            
            $setvalue = "procedure_name=:procedure_name,procedure_price=:procedure_price";
            $wherecon = "where procedure_id = '".$upprocedure_id."' ";
            $execon = array(":procedure_name"=>$proceudrenameedit,":procedure_price"=>$procedurepriceedit);
            $updateprocudure = update("procedures",$setvalue,$wherecon,$execon);
            
            $result = array("Status"=>"ok","updateprocudure"=>$updateprocudure);
	        echo json_encode($result);
        }
        
        if(isset($postdata->editprocedure))
        {
            $procedure_id = $postdata->procedure_id;
            $findprodetails = find("first","procedures","*","where procedure_id = '".$procedure_id."' ",array());
            
            $result = array("Status"=>"ok","findprodetails"=>$findprodetails);
	        echo json_encode($result);
        }
        
        if(isset($postdata->add_staff))
        {
            $staff_name = $postdata->staff_name;
            $staff_email = $postdata->staff_email;
            $mobile_number = $postdata->mobile_number;
            $role = $postdata->role;
            
            $findalreadystaff = find("first","staff","*","where staff_email = '".$staff_email."' ",array());
            
            if($findalreadystaff){
                $savestaff = "Staff already add";
            } else {
                $fileds = "staff_name,staff_email,mobile_number,password,role_id,status,created_at";
                $values = ":staff_name,:staff_email,:mobile_number,:password,:role_id,:status,:created_at";
                $exe = array(
                    ":staff_name" => $staff_name ,
                    ":staff_email" => $staff_email,
                    ":mobile_number" => $mobile_number,
                    ":password" => '123456',
                    ":role_id" => $role,
                    ":status" => "Y",
                    ":created_at" => date("Y-m-d H:i:s"),
                );
    
                $savestaff = save("staff",$fileds,$values,$exe);
                
                if($savestaff){
                    savenotification("0",$savestaff,"","staff","You were added to portal","You were successfully addedd to our portal"); 
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL,"https://tdtl.info/coreconcept/ws/PHPMailer/send_staff_add.php");
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS,"savestaff=$savestaff");
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $server_output = curl_exec($ch);
                    curl_close ($ch);
                }
            }

            $result = array("Status"=>"ok","savestaff"=>$savestaff);
	        echo json_encode($result);
        }

        if(isset($postdata->fetch_staff))
        {
            $findstafflist = find("all","staff inner join role on staff.role_id=role.role_id","*","where 1",array());

            $result = array("Status"=>"ok","findstafflist"=>$findstafflist);
	        echo json_encode($result);
        }

        if(isset($postdata->add_schedule))
        {
            $day = $postdata->day;
            $intime = $postdata->intime;
            $outtime = $postdata->outtime;
            $mode = $postdata->mode;
            $docid = $postdata->docid;

            $findsavedday = find("first","doc_schedule","*","where day = '".$day."' and doctor_id = '".$docid."' ",array());
            if($findsavedday)
            {
                $setvalues = "in_time=:in_time,out_time=:out_time,mode=:mode";
                $wherecon = "where day = '".$day."' and doctor_id = '".$docid."' ";
                $execon = array(":in_time"=>$intime,":out_time"=>$outtime,":mode"=>$mode);
                $savesch = update("doc_schedule",$setvalues,$wherecon,$execon);
            } else {
                $fields = "doctor_id,day,in_time,out_time,mode,created_at";
                $values = ":doctor_id,:day,:in_time,:out_time,:mode,:created_at";
                $exe = array(
                        ":doctor_id" => $docid,
                        ":day" => $day,
                        ":in_time" => $intime,
                        ":out_time" => $outtime,
                        ":mode" => $mode,
                        ":created_at" => date("Y-m-d H:i:s"),
                    );
                $savesch = save("doc_schedule",$fields,$values,$exe);
            }
            
            if($savesch){
                savenotification("0",$docid,"","doctor","Schedule Added or Updated","Your weekly schedule is updated or added on portal."); 
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL,"https://tdtl.info/coreconcept/ws/PHPMailer/send_doc_sch.php");
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS,"docid=$docid");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $server_output = curl_exec($ch);
                curl_close ($ch);
            }

            $result = array("Status"=>"ok","savesch"=>$savesch);
	        echo json_encode($result);
        }

        if(isset($postdata->fetchschdata))
        {
            $docid = $postdata->docid;

            $findschall = find("all","doc_schedule","*","where doctor_id = '".$docid."' ",array());

            $result = array("Status"=>"ok","findschall"=>$findschall);
	        echo json_encode($result);
        }

        if(isset($postdata->add_category))
        {
            $category_name = $postdata->category_name;
            $doctor_id = $postdata->doctor_id;

            $fileds = "category_name,doctor_id,created_at";
            $values = ":category_name,:doctor_id,:created_at";
            $exe = array(
                ":category_name"=>$category_name,
                ":doctor_id"=>$doctor_id,
                ":created_at"=>date("Y-m-d H:i:s"),
            );
            $savecat = save("category",$fileds,$values,$exe);
            
            $result = array("Status"=>"ok","savecat"=>$savecat);
	        echo json_encode($result);
        }
    }
?>