<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->add_module))
        {
            $module_name = (isset($postdata->module_name)) ? $postdata->module_name : "";
            $module_order = (isset($postdata->module_order)) ? $postdata->module_order : "";
            $module_link = (isset($postdata->module_link)) ? $postdata->module_link : "";
            $module_icon = (isset($postdata->module_icon)) ? $postdata->module_icon : "";
            $module_parent = (isset($postdata->module_parent)) ? $postdata->module_parent : "";
            
            $fields = 'module_name,module_order,module_parent_id,module_link,iconname';
            $values = ':module_name,:module_order,:module_parent_id,:module_link,:iconname';
            $exe = array(
                            ":module_name" => $module_name,
                            ":module_order" => $module_order,
                            ":module_parent_id" => $module_parent,
                            ":module_link" => $module_link,
                            ":iconname" => $module_icon,
                        );
            $savemodule = save('module',$fields,$values,$exe);

            $result = array("Status"=>"ok","savemodule"=>$savemodule);
	        echo json_encode($result);
        }

        if(isset($postdata->fetch_module))
        {
            $findmodules = find("all","module","*","where 1",array());
            
            $result = array("Status"=>"ok","findmodules"=>$findmodules);
	        echo json_encode($result);
        }

        if(isset($postdata->fetchsidebar))
        {
            $userid = $postdata->userid;
            $user = $postdata->user;

            if($user == "Admin"){
                $findmodules = find("all","module","*","where module_parent_id = '' ",array());
            } else if($user == "Doctor"){
                $findroleid = find("first","doctor","*","where doctor_id = '".$userid."' ",array());
                $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$findroleid['role_id']."' ",array());
                $findmodules = find("all","module inner join rolemodule on module.module_id = rolemodule.module_id","*","where rolemodule.role_id = '".$findroleid['role_id']."' and module.module_parent_id = '' ",array());
            } else if($user == "Patient"){
                $findroleid = find("first","patient","*","where patient_id = '".$userid."' ",array());
                $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$findroleid['role_id']."' ",array());
                $findmodules = find("all","module inner join rolemodule on module.module_id = rolemodule.module_id","*","where rolemodule.role_id = '".$findroleid['role_id']."' and module.module_parent_id = '' ",array());
                // foreach($findroles as $vals){
                //     array_push($roleidarr,$vals['module_id']);
                //     array_push($roleslugarr, strtolower($vals['module_slug']));
                // }
            } else if($user == "Staff"){
                $findroleid = find("first","staff","*","where staff_id = '".$userid."' ",array());
                $findroles = find("all","role inner join rolemodule on role.role_id=rolemodule.role_id","*","where role.role_id = '".$findroleid['role_id']."' ",array());
                $findmodules = find("all","module inner join rolemodule on module.module_id = rolemodule.module_id","*","where rolemodule.role_id = '".$findroleid['role_id']."' and module.module_parent_id = '' ",array());
            }



            // $findmodules = find("all","module","*","where module_parent_id = '' ",array());

            $result = array("Status"=>"ok","findmodules"=>$findmodules);
	        echo json_encode($result);
        }

    }
    // $result = array("Status"=>"ok","findmodules"=>$findmodules);
	// echo json_encode($result);
?>