<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        // if($postdata->add_dept == 'yes')
        if(isset($postdata->add_dept))
        {
            $dept_name = $postdata->dept_name;
            $savedept = save('department','dept_name',':dept_name',array(":dept_name"=>$dept_name));
            
            $result = array("Status"=>"ok","savedept"=>$savedept);
	        echo json_encode($result);
        }

        if(isset($postdata->fetch_add_doc_data))
        {
            $finddept = find('all','department','*','where 1',array());

            $result = array("Status"=>"ok","finddept"=>$finddept);
	        echo json_encode($result);
        }

    }
    // $result = array("Status"=>"ok","savedept"=>$savedept,"finddept"=>$finddept);
	// echo json_encode($result);
?>