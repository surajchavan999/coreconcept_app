<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));
		
		if(isset($postdata->changetreatstatus))
		{
		    $treatstatus = $postdata->treatstatus;
		    $appidforchg = $postdata->appidforchg;
		    
		    if($treatstatus == "W"){
		        $setvalue = "treatment_status=:treatment_status,waiting_time=:waiting_time";
		        $execon = array(":treatment_status"=>$treatstatus,":waiting_time"=>date("H:i:s"));
		    }
		    if($treatstatus == "E"){
		        $setvalue = "treatment_status=:treatment_status,engage_time=:engage_time";
		        $execon = array(":treatment_status"=>$treatstatus,":engage_time"=>date("H:i:s"));
		    }
		    if($treatstatus == "D"){
		        $setvalue = "treatment_status=:treatment_status,done_time=:done_time";
		        $execon = array(":treatment_status"=>$treatstatus,":done_time"=>date("H:i:s"));
		    }
		    
		    $wherecon = "where appointment_id = '".$appidforchg."' ";
		    $updatetreatstatus = update("appointment",$setvalue,$wherecon,$execon);
		    
		    $result = array("Status"=>"ok","updatetreatstatus"=>$updatetreatstatus);
	        echo json_encode($result);
		}
		
		if(isset($postdata->fetchcalapp))
		{
		    $appid = $postdata->appid;
		    
		    $findcalappdetail = find("first","appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id inner join patient on patient.patient_id=appointment.patient_id","*","where appointment_id = '".$appid."' ",array());
		    
		    $result = array("Status"=>"ok","findcalappdetail"=>$findcalappdetail);
	        echo json_encode($result);
		}
		
		if(isset($postdata->fetchdashboard))
        {
            $user = $postdata->user;
            $userid = $postdata->userid;
            
            $tableappoit = "appointment INNER JOIN department on appointment.dept_id=department.dept_id INNER JOIN doctor on doctor.doctor_id = appointment.doc_id inner join patient on patient.patient_id=appointment.patient_id";
            if($user == "Admin"){
                $findtodayapp = find("all",$tableappoit,"*, appointment.status as astatus","where appointment.schedule_date = '".date("Y-m-d")."' order by appointment.start_time ASC ",array());
            }
            if($user == "Doctor"){
                $findtodayapp = find("all",$tableappoit,"*, appointment.status as astatus","where appointment.doc_id = '".$userid."' and appointment.schedule_date = '".date("Y-m-d")."' order by appointment.start_time ASC ",array());
            }
            if($user == "Staff"){
                $findtodayapp = find("all",$tableappoit,"*, appointment.status as astatus","where appointment.schedule_date = '".date("Y-m-d")."' order by appointment.start_time ASC ",array());
            }
            if($user == "Patient"){
                $findtodayapp = find("all",$tableappoit,"*, appointment.status as astatus","where appointment.patient_id = '".$userid."' and appointment.schedule_date = '".date("Y-m-d")."' order by appointment.start_time ASC ",array());
            }
            
            
            $findappevent = find("all",$tableappoit,"*","where 1",array());
            // $findeventcolor = find("first","doctor","*","where 1",array());
            $eventarr = [];
            foreach($findappevent as $key=>$val){
                array_push($eventarr,array("id"=>$val['appointment_id'],"title"=>$val['patient_name'],"start"=>$val['schedule_date']."T".$val['start_time'],"end"=>$val['schedule_date']."T".$val['end_time']));
            }
            
            // $findalltreatstatus = find("first","appointment","COUNT(treatment_status) as totalcount, COUNT(IF(treatment_status='D',1,null)) AS done,COUNT(IF(treatment_status='W',1,null)) AS waiting, COUNT(IF(treatment_status='E',1,null)) AS engaged","where schedule_date = '".date("Y-m-d")."' ",array());
            $findallwaiting = find("first","appointment","COUNT(treatment_status) as waiting ","where treatment_status='W' and schedule_date = '".date("Y-m-d")."' ",array());
            $findallengage = find("first","appointment","COUNT(treatment_status) as engaged ","where treatment_status='E' and schedule_date = '".date("Y-m-d")."' ",array());
            $findalldone = find("first","appointment","COUNT(treatment_status) as done ","where treatment_status='D' and schedule_date = '".date("Y-m-d")."' ",array());
            $findalltotal = find("first","appointment","COUNT(treatment_status) as totalcount ","where schedule_date = '".date("Y-m-d")."' ",array());
            
            $findalltreatstatus = array("waiting"=>$findallwaiting['waiting'],"engaged"=>$findallengage['engaged'],"done"=>$findalldone['done'],"totalcount"=>$findalltotal['totalcount']);
            
            $deptarr = [["Department","Doctors"]];
            $pdeptarr = [["Department","Doctors"]];
            $finddept = find("all","department","*","where 1",array());
            foreach($finddept as $k=>$v){
                $finddoc = find("first","doctor"," COUNT(*) as MatchValues, (SELECT COUNT(*) FROM doctor) as TotalRecords, CAST(COUNT(*) AS FLOAT)/CAST((SELECT COUNT(*) FROM doctor) AS FLOAT)*100 as Percentage ","where dept_id = '".$v['dept_id']."' ",array());
                $temparr = array($v['dept_name'],(int)$finddoc['Percentage']);
                array_push($deptarr,$temparr);
                
                
                $findpatient = find("first","appointment","COUNT(patient_id) as MatchValues, (SELECT COUNT(patient_id) FROM appointment) as TotalRecords, CAST(COUNT(patient_id) AS FLOAT)/CAST((SELECT COUNT(patient_id) FROM appointment) AS FLOAT)*100 as Percentage","where dept_id = '".$v['dept_id']."' ",array());
                $temparr2 = array($v['dept_name'],(int)$findpatient['Percentage']);
                array_push($pdeptarr,$temparr2);
            }
            
            
            $result = array("Status"=>"ok","deptarr"=>$deptarr,"pdeptarr"=>$pdeptarr,"findtodayapp"=>$findtodayapp,"eventarr"=>$eventarr,"findalltreatstatus"=>$findalltreatstatus);
	        echo json_encode($result);
        }
	}
?>