<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->deletereciept))
        {
            $acceptpay_id = $postdata->acceptpay_id;
            $deletereciept = delete("acceptpayment","where acceptpay_id = '".$acceptpay_id."' ",array());
            $result = array("Status"=>"ok","deletereciept"=>$deletereciept);
            echo json_encode($result);
        }
        
        if(isset($postdata->deleteinvoice))
        {
            $invoices_id = $postdata->invoices_id;
            $deleteinvoice = delete("invoices","where invoices_id = '".$invoices_id."' ",array());
            $result = array("Status"=>"ok","deleteinvoice"=>$deleteinvoice);
            echo json_encode($result);
        }
        
        if(isset($postdata->dataeditinn))
        {
            $treatname = $postdata->treatname;
            $unitcost = $postdata->unitcost;
            $qty = $postdata->qty;
            $distype = $postdata->distype;
            $discountval = $postdata->discountval;
            $invoiceid = $postdata->invoiceid;
            
            $setvalues = "treatment_name=:treatment_name,unit_cost=:unit_cost,quantity=:quantity,discount=:discount,discount_type=:discount_type";
            $wherecon = "where invoices_id = '".$invoiceid."' ";
            $execon = array(":treatment_name"=>$treatname,":unit_cost"=>$unitcost,":quantity"=>$qty,":discount"=>$discountval,":discount_type"=>$distype);
            $updateeditinvoice = update("invoices",$setvalues,$wherecon,$execon);
            
            $result = array("Status"=>"ok","updateeditinvoice"=>$updateeditinvoice);
            echo json_encode($result);
        }
        
        if(isset($postdata->datainedit))
        {
            $invoiceid = $postdata->invoiceid;
            
            $finndinnvoicedetaisl = find("first","invoices","*","where invoices_id = '".$invoiceid."' ",array());
            
            $result = array("Status"=>"ok","finndinnvoicedetaisl"=>$finndinnvoicedetaisl);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchtreatdata))
        {
            $tid = $postdata->tid;
            
            $findtreatdetials = find("first","procedures","*","where procedure_id = '".$tid."' ",array());
            
            $result = array("Status"=>"ok","findtreatdetials"=>$findtreatdetials);
            echo json_encode($result);
        }
        
        if(isset($postdata->dataaddmodel))
        {
            
            $findalltherypy = find("all","procedures","*","where 1",array());
            
            $result = array("Status"=>"ok","findalltherypy"=>$findalltherypy);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchinnpatapp))
        {
            $appid = $postdata->appid;
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $findapp = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            $findallinnvoice = find("all","invoices","*","where patient_id = '".$findpid['patient_id']."' and appointment_id = '".$appid."' ",array());
            
            $findtotalpaidamt = find("first","acceptpayment","SUM(amount) as totalpaid","where patient_id = '".$findpid['patient_id']."' and appoitment_id = '".$appid."' ",array());
            $findacceptrec = find("all","acceptpayment","*","where patient_id = '".$findpid['patient_id']."' and appoitment_id = '".$appid."' ",array());
            
            $result = array("Status"=>"ok","findallinnvoice"=>$findallinnvoice,"findpid"=>$findpid,"findapp"=>$findapp,"findtotalpaidamt"=>$findtotalpaidamt,"findacceptrec"=>$findacceptrec);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchmaininnpdata))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            
            $findallapp = find("all","appointment","*","where patient_id = '".$findpid['patient_id']."' order by schedule_date DESC ",array());
            foreach($findallapp as $k=>$v){
                $fininnvoice = find("first","invoices","invoice_number,SUM(unit_cost) as total_amount,status as innvoicestatus","where appointment_id = '".$v['appointment_id']."' ",array());
                $findallapp[$k] = array_merge($findallapp[$k],$fininnvoice);
            }
            
            $result = array("Status"=>"ok","findallapp"=>$findallapp);
            echo json_encode($result);
        }
        
        
        if(isset($postdata->sendpdftomail))
        {
            // print_r($_FILES);
            // print_r($_POST);
            // print_r($postdata->pdfData);
            // echo "<br><br><br><br><br><br><br><br><br><br><br>";
            // print_r(base64_decode($postdata->pdfData));
            
            // $data = base64_decode($postdata->pdfData);
            // header('Content-Type: application/pdf');
            // echo $data;
            // print_r($postdata->findallinnvoice);
            // $findallinnvoice = json_decode($postdata->findallinnvoice);
            // foreach($findallinnvoice as $val){
            //     print_r($val);echo "<br><br><br><br>";
            // }
            // exit();
            // $mailcontent = $postdata->mailcontent;
            // echo $mailcontent;
            
            
            $findallinnvoice = $postdata->findallinnvoice;
            $findpid = $postdata->findpid;
            $findpidemail = $postdata->findpid;
            $findtpa = json_decode($postdata->findpid);
            
            $appid = $postdata->appid;
            
            $findtotalpaidamt = find("first","acceptpayment","SUM(amount) as totalpaid","where patient_id = '".$findtpa->patient_id."' and appoitment_id = '".$appid."' ",array())['totalpaid'];
            // print_r($findtotalpaidamt);
            // exit();
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,"https://clinic.coreconcept.in/ws/html2pdf/index.php");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,"findallinnvoice=$findallinnvoice&findpid=$findpid&findtotalpaidamt=$findtotalpaidamt");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $server_output = curl_exec($ch);
            curl_close ($ch);
            // print_r($server_output);
            // exit();
            $filename = $server_output;
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,"https://clinic.coreconcept.in/ws/PHPMailer/sendinnvoiceinmail.php");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,"filename=$filename&findpidemail=$findpidemail");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $server_output = curl_exec($ch);
            curl_close ($ch);
            print_r($server_output);
        }
        
        if(isset($postdata->fetchledgers))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            
            $findledgerrec = find("all","acceptpayment","*, acceptpayment.payment_date as ledgerdate","where patient_id = '".$findpid['patient_id']."' ",array());
            $findallinnvledger = find("all","invoices","*, invoices.created_at as ledgerdate","where patient_id = '".$findpid['patient_id']."' ",array());
            
            $ledgerarr = array_merge($findledgerrec,$findallinnvledger);
            // print_r($ledgerarr);exit();
            function compare_dates($a, $b) {
                return strtotime($a['ledgerdate']) - strtotime($b['ledgerdate']);
            }
            usort($ledgerarr, "compare_dates");
            // print_r($ledgerarr);
            
            $result = array("Status"=>"ok","findledgerrec"=>$findledgerrec,"findallinnvledger"=>$findallinnvledger,"ledgerarr"=>$ledgerarr);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchbills))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            
            $findbillrec = find("all","acceptpayment","*","where patient_id = '".$findpid['patient_id']."' ",array());
            $findinnvoicetotal = find("first","invoices","SUM(unit_cost * quantity) as totalinvoice","where patient_id = '".$findpid['patient_id']."' ",array());
            
            $result = array("Status"=>"ok","findbillrec"=>$findbillrec,"findinnvoicetotal"=>$findinnvoicetotal);
            echo json_encode($result);
        }
        
        if(isset($postdata->acceptpayment))
        {
            function reciptno(){
                $rno = "REC".rand(1,9999);
                $findinvono = find("first","acceptpayment","*","where recept_no = '".$rno."' ",array());
                if($findinvono){
                    reciptno();
                } else {
                    return $rno;
                }
            }
            $amttopay = isset($postdata->amttopay) ? $postdata->amttopay : "" ;
            $modeopay = isset($postdata->modeopay) ? $postdata->modeopay : "" ;
            $bankname = isset($postdata->bankname) ? $postdata->bankname : "" ;
            $chequeno = isset($postdata->chequeno) ? $postdata->chequeno : "" ;
            $last4digino = isset($postdata->last4digino) ? $postdata->last4digino : "" ;
            $transactionno = isset($postdata->transactionno) ? $postdata->transactionno : "" ;
            $puid = isset($postdata->puid) ? $postdata->puid : "" ;
            $appid = isset($postdata->appid) ? $postdata->appid : "" ;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            
            $fields = "appoitment_id,patient_id,amount,modeofpay,bankname,chequeno,last4digino,transactionno,recept_no,payment_date";
            $values = ":appoitment_id,:patient_id,:amount,:modeofpay,:bankname,:chequeno,:last4digino,:transactionno,:recept_no,:payment_date";
            $exe = array(
                ":appoitment_id" => $appid,
                ":patient_id" => $findpid['patient_id'],
                ":amount" => $amttopay,
                ":modeofpay" => $modeopay,
                ":bankname" => $bankname,
                ":chequeno" => $chequeno,
                ":last4digino" => $last4digino,
                ":transactionno" => $transactionno,
                ":recept_no" => reciptno(),
                ":payment_date" => date("Y-m-d H:i:s"),
                );
            $saverec = save("acceptpayment",$fields,$values,$exe);
            
            $result = array("Status"=>"ok","saverec"=>$saverec);
            echo json_encode($result);
        }
        
        if(isset($postdata->saveinnvoice))
        {
            $treatname = $postdata->treatname;
            $unitcost = $postdata->unitcost;
            $qty = $postdata->qty;
            $distype = $postdata->distype;
            $discountval = $postdata->discountval;
            $consession = $postdata->consession;
            $puid = $postdata->puid;
            $appid = $postdata->appid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $findapp = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            
            $findinnvoicenum = find("first","invoices","*","where patient_id = '".$findpid['patient_id']."' and appointment_id = '".$appid."' ",array());
            
            $fields = "invoice_number,appointment_id,patient_id,doctor_id,treatment_name,dept_id,unit_cost,quantity,discount,discount_type,cancelled,status,showtp,created_at";
            $values = ":invoice_number,:appointment_id,:patient_id,:doctor_id,:treatment_name,:dept_id,:unit_cost,:quantity,:discount,:discount_type,:cancelled,:status,:showtp,:created_at";
            $exe = array(
                ":invoice_number" => $findinnvoicenum['invoice_number'],
                ":appointment_id" => $appid,
                ":patient_id" => $findpid['patient_id'],
                ":doctor_id" => $findapp['doc_id'],
                ":treatment_name" => $treatname,
                ":dept_id" => $findapp['dept_id'],
                ":unit_cost" => $unitcost,
                ":quantity" => $qty,
                ":discount" => $discountval,
                ":discount_type" => $distype,
                ":cancelled" => "0",
                ":status" => "U",
                ":showtp" => "Y",
                ":created_at" => date("Y-m-d H:i:s")
                );
            $saveinnvoice = save("invoices",$fields,$values,$exe);
            $result = array("Status"=>"ok","saveinnvoice"=>$saveinnvoice);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchinvoiceviewdtat))
        {
            $appid = $postdata->appid;
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            $findapp = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            $findallinnvoice = find("all","invoices","*","where patient_id = '".$findpid['patient_id']."' and appointment_id = '".$appid."' ",array());
            
            $findtotalpaidamt = find("first","acceptpayment","SUM(amount) as totalpaid","where patient_id = '".$findpid['patient_id']."' and appoitment_id = '".$appid."' ",array());
            $findacceptrec = find("all","acceptpayment","*","where patient_id = '".$findpid['patient_id']."' and appoitment_id = '".$appid."' ",array());
            
            $result = array("Status"=>"ok","findallinnvoice"=>$findallinnvoice,"findpid"=>$findpid,"findapp"=>$findapp,"findtotalpaidamt"=>$findtotalpaidamt,"findacceptrec"=>$findacceptrec);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchtindata))
        {
            $puid = $postdata->puid;
            $findpid = find('first','patient','*',"where unique_pid = '".$puid."' ",array());
            
            $findallinvoice = find("all","invoices","*","where patient_id = '".$findpid['patient_id']."' ",array());
            
            $findallapp = find("all","appointment","*","where patient_id = '".$findpid['patient_id']."' order by schedule_date DESC ",array());
            foreach($findallapp as $k=>$v){
                $fininnvoice = find("first","invoices","invoice_number,SUM(unit_cost) as total_amount,status as innvoicestatus","where appointment_id = '".$v['appointment_id']."' ",array());
                $findallapp[$k] = array_merge($findallapp[$k],$fininnvoice);
            }
            
            $findallinvoiceunique = find("all","invoices","*","where patient_id = '".$findpid['patient_id']."' group by invoice_number ",array());
            
            $result = array("Status"=>"ok","findallinvoice"=>$findallinvoice,"findallinvoiceunique"=>$findallinvoiceunique,"findallapp"=>$findallapp);
            echo json_encode($result);
        }

        if(isset($postdata->changepstatus))
        {
            $status = $postdata->status;
            $innid = $postdata->innid;
            $stp = $postdata->stp;
            
            $set = "status=:status,showtp=:showtp";
            $wherecon = "where invoices_id = '".$innid."' ";
            $exe = array(":status"=>$status,":showtp"=>$stp);
            
            $updaateps = update("invoices",$set,$wherecon,$exe);
            $result = array("Status"=>"ok","updaateps"=>$updaateps);
            echo json_encode($result);
        }
        
        if(isset($postdata->fetchdatainnd))
        {
            $user = $postdata->user;
            if($user === "Admin")
            {
                $findallinnapt = find("all","invoices INNER JOIN patient on patient.patient_id=invoices.patient_id","patient.unique_pid, invoices.patient_id, patient_name, discount_type, discount, SUM(unit_cost * quantity) as totalamt","where 1 group by patient_id ORDER by invoices.created_at DESC",array());
                // $pids = [];
                // foreach($findallinnapt as $v){array_push($pids,$v['patient_id']);}
                // $fininnvoice = find("first","invoices","invoice_number,SUM(unit_cost) as total_amount,status as innvoicestatus","where appointment_id = '".$v['appointment_id']."' ",array());
                // $findallinnpat = find("all","patient","*","where patient_id in (".implode(",",$pids).") ",array());
                
                $findpinndata = find("all","invoices","*","where 1",array());
            }
            if($user === "Patient")
            {
                $pid = $postdata->uid;
                $findpinndata = find("all","invoices","*","where patient_id = '".$pid."' and showtp = 'Y' ",array());
                // $findallinnapt = find("all","invoices INNER JOIN patient on patient.patient_id=invoices.patient_id","patient.unique_pid, invoices.patient_id, patient_name, discount_type, discount, SUM(unit_cost * quantity) as totalamt","where 1 group by patient_id ORDER by invoices.created_at DESC",array());
            }
            if($user === "Doctor")
            {
                $findallinnapt = find("all","invoices INNER JOIN patient on patient.patient_id=invoices.patient_id","patient.unique_pid, invoices.patient_id, patient_name, discount_type, discount, SUM(unit_cost * quantity) as totalamt","where 1 group by patient_id ORDER by invoices.created_at DESC",array());
                $pid = $postdata->uid;
                $findpinndata = find("all","invoices","*","where 1",array());
            }
            if($user === "Staff")
            {
                // $findallinnapt = find("all","invoices INNER JOIN patient on patient.patient_id=invoices.patient_id","patient.unique_pid, invoices.patient_id, patient_name, discount_type, discount, SUM(unit_cost * quantity) as totalamt","where 1 group by patient_id ORDER by invoices.created_at",array());
                $pid = $postdata->uid;
                $findpinndata = find("all","invoices","*","where 1",array());
                $findallinnapt = find("all","invoices INNER JOIN patient on patient.patient_id=invoices.patient_id","patient.unique_pid, invoices.patient_id, patient_name, discount_type, discount, SUM(unit_cost * quantity) as totalamt","where 1 group by patient_id ORDER by invoices.created_at DESC",array());
            }
            $result = array("Status"=>"ok","findpinndata"=>$findpinndata,"findallinnpat"=>$findallinnapt);
            echo json_encode($result);
        }
    }
?>