<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->add_patient))
        {
            $fullname = (isset($postdata->fullname)) ? $postdata->fullname : "";
            $pmail = (isset($postdata->pmail)) ? $postdata->pmail : "";
            $pphone = (isset($postdata->pphone)) ? $postdata->pphone : "";
            $imageSrc = (isset($postdata->imageSrc)) ? $postdata->imageSrc : "";
            $pcity = (isset($postdata->pcity)) ? $postdata->pcity : "";
            $pdistrict = (isset($postdata->pdistrict)) ? $postdata->pdistrict : "";
            $pdob = (isset($postdata->pdob)) ? $postdata->pdob : "";
            $paddres = (isset($postdata->paddres)) ? $postdata->paddres : "";
            $psex = (isset($postdata->psex)) ? $postdata->psex : "";
            $bloodgroup = isset($postdata->bloodgroup) ? $postdata->bloodgroup : "";
            $ppincode = isset($postdata->ppincode) ? $postdata->ppincode : "";
            $referredby = isset($postdata->referredby) ? $postdata->referredby : "";
            $pid = $postdata->pid;

            $fields = "unique_pid,patient_name,email,password,mobile_number,profile_picture,pro_pic_data,gender,city,district,address,ppincode,bloodgroup,dob,referredby,role_id,created_at";
            $values = ":unique_pid,:patient_name,:email,:password,:mobile_number,:profile_picture,:pro_pic_data,:gender,:city,:district,:address,:ppincode,:bloodgroup,:dob,:referredby,:role_id,:created_at";
            $exe = array(
                ":unique_pid" => $pid,
                ":patient_name" => $fullname,
                ":email" => $pmail,
                ":password" => "123456",
                ":mobile_number" => $pphone,
                ":profile_picture" => "",
                ":pro_pic_data" => $imageSrc,
                ":gender" => $psex,
                ":city"=>$pcity,
                ":district"=>$pdistrict,
                ":address"=>$paddres,
                ":ppincode" => $ppincode,
                ":bloodgroup" => $bloodgroup,
                ":dob"=>$pdob,
                ":referredby"=>$referredby,
                ":role_id" => '2',
                ":created_at" => date("Y-m-d H:i:s"),
            );
            if($pmail == ""){
                $findalreadypatient = find("first","patient","*","where mobile_number = '".$pphone."' ",array());
                if($findalreadypatient){
                    $savepatient = "Patient Already Added";
                } else {
                    $savepatient = save("patient",$fields,$values,$exe);
                }
            } 
            else {
                $findalreadypatient = find("first","patient","*","where email = '".$pmail."' ",array());
                if($findalreadypatient){
                    $savepatient = "Patient Already Added";
                } else {
                    $savepatient = save("patient",$fields,$values,$exe);
                }
            }

            // if($savepatient > 0)
            // {
            //     foreach($postdata as $key=>$val){
            //     if($key != 'add_patient' && $key != 'fullname' && $key != 'pmail' && $key != 'pphone' && $key != 'pid')
            //         {
            //             $fields1 = "patient_id,meta_key,meta_value";
            //             $values1 = ":patient_id,:meta_key,:meta_value";
            //             $exe1 = array(
            //                         ":patient_id"=>$savepatient,
            //                         ":meta_key"=> $key,
            //                         ":meta_value"=>$val,
            //                     );
            //             $savepatientmeta = save("patient_meta",$fields1,$values1,$exe1);
            //         }
            //     }
            // }
            
            // savenotification("0",$savepatient,"","patient","You were added to portal","You were successfully addedd to our portal"); 
            // $ch = curl_init();
            // curl_setopt($ch, CURLOPT_URL,"https://tdtl.info/coreconcept/ws/PHPMailer/send_patient_add.php");
            // curl_setopt($ch, CURLOPT_POST, 1);
            // curl_setopt($ch, CURLOPT_POSTFIELDS,"savepatient=$savepatient");
            // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            // $server_output = curl_exec($ch);
            // curl_close ($ch);
            
            $result = array("Status"=>"ok","savepatient"=>$savepatient);//,"savepatientmeta"=>$savepatientmeta);
	        echo json_encode($result);
        }

        if(isset($_POST['saveproimg']))
        {
            $pid = $_POST['pid'];
            $patientid = $_POST['patientid'];
            
            // $imageSrc = $_POST['imageSrc'];print_r($_POST);exit();
            if(isset($_FILES['imagefile'])){
                $file_ext = strtolower(explode('.',$_FILES['imagefile']['name'])[1]);
                $imagefile = $_FILES['imagefile']['name'];
                $tempname = $_FILES['imagefile']['tmp_name'];
                $targetwithfile = "uploads/profile_picture/".$pid.".".$file_ext;
                move_uploaded_file($tempname,$targetwithfile);

                $setvalue = "profile_picture=:profile_picture";
                $wherecon = "where patient_id = '".$patientid."' ";
                $execon = array(":profile_picture"=>$targetwithfile);
                $updatepropicurl = update("patient",$setvalue,$wherecon,$execon);
            }
            // if($_POST['imageSrc'] != "" ){
            //     $setvalue = "pro_pic_data=:pro_pic_data";
            //     $wherecon = "where patient_id = '".$patientid."' ";
            //     $execon = array(":pro_pic_data"=>$imageSrc);
            //     $updatepropicurl = update("patient",$setvalue,$wherecon,$execon);
            // }

            $result = array("Status"=>"ok","updatepropicurl"=>$updatepropicurl);
            echo json_encode($result);
        }
        
        if(isset($postdata->addpatientmeta))
        {
            $appid = $postdata->appid;
            $findappdetilas = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            $patient_id = $findappdetilas['patient_id'];
            $findunipuepid = find("first","patient","*","where patient_id = '".$patient_id."' ",array());
            $savepatientmeta = 0;
            $updatepmeta = false;
            $findalreadyfilleddata = find("all","patient_meta","*","where appointment_id = '".$appid."' and patient_id = '".$patient_id."' ",array());
            if($findalreadyfilleddata){
                foreach($postdata as $key=>$val){
                    if($key != 'addpatientmeta' && $key != 'appid')
                    {
                        $findmetakeyalready = find("first","patient_meta","*","where appointment_id = '".$appid."' and patient_id = '".$patient_id."' and meta_key = '".$key."'",array());
                        if($findmetakeyalready){
                            $setvalue = "meta_value=:meta_value";
                            $wherecon = "where appointment_id = '".$appid."' and patient_id = '".$patient_id."' and meta_key = '".$key."' ";
                            $execon = array(":meta_value"=>$val);
                            $updatepmeta = update("patient_meta",$setvalue,$wherecon,$execon);
                        } else {
                            $fields1 = "patient_id,appointment_id,meta_key,meta_value";
                            $values1 = ":patient_id,:appointment_id,:meta_key,:meta_value";
                            $exe1 = array(
                                        ":patient_id"=>$patient_id,
                                        ":appointment_id"=>$appid,
                                        ":meta_key"=> $key,
                                        ":meta_value"=>$val,
                                    );
                            $savepatientmeta = save("patient_meta",$fields1,$values1,$exe1);
                        }
                    }
                }
            } else {
                foreach($postdata as $key=>$val){
                    if($key != 'addpatientmeta' && $key != 'appid')
                    {
                        $fields1 = "patient_id,appointment_id,meta_key,meta_value";
                        $values1 = ":patient_id,:appointment_id,:meta_key,:meta_value";
                        $exe1 = array(
                                    ":patient_id"=>$patient_id,
                                    ":appointment_id"=>$appid,
                                    ":meta_key"=> $key,
                                    ":meta_value"=>$val,
                                );
                        $savepatientmeta = save("patient_meta",$fields1,$values1,$exe1);
                    }
                }
            }
            $result = array("Status"=>"ok","savepatientmeta"=>$savepatientmeta,"updatepmeta"=>$updatepmeta,"unique_pid"=>$findunipuepid['unique_pid']);
            echo json_encode($result);
            
        }

        if(isset($postdata->fetch_patient))
        {
            $findpatient = find("all","patient","*","where 1 order by created_at DESC",array());

            foreach($findpatient as $keys=>$vals){
                $findpatientmeta = find("all","patient_meta","*","where patient_id = '".$vals['patient_id']."' ",array());
                foreach($findpatientmeta as $kk=>$vv){
                    if($vv['meta_key'] == "psex"){
                        $gender = $vv['meta_value'];
                        $temparr = array("gender"=>$gender);
                        $findpatient[$keys] = array_merge($findpatient[$keys],$temparr);
                    }
                }
                // print_r($findpatientmeta);
            }

            // print_r($findpatient);

            $result = array("Status"=>"ok","findpatient"=>$findpatient);
	        echo json_encode($result);
        }

        if(isset($postdata->fetchapdata))
        {
            function uniquegenerate()
            {
                $pids = "P".rand(10000,99999);
                $finduniquepid = find("first","patient","*","where unique_pid = '".$pids."' ",array());
                
                if($finduniquepid)
                {
                    uniquegenerate();
                }
                else { return $pids; }
            }


            $pid = uniquegenerate();

            $result = array("Status"=>"ok","pid"=>$pid);
	        echo json_encode($result);
        }

        if(isset($postdata->fetchpddata))
        {
            // $findallpatient = find("all","patient","*","where 1",array());

            $patientuid = $postdata->patientid;

            $findpid = find("first","patient","*","where unique_pid = '".$patientuid."' ",array());

            // $findpaatientmetadata = find("all","patient_meta","*","where patient_id = '".$findpid['patient_id']."' ",array());
            // $metaarr = array();
            // foreach($findpaatientmetadata as $k=>$v){
            //     $temparr = array($v['meta_key']=>$v['meta_value']);
            //     $metaarr = array_merge($metaarr,$temparr);
            // }

            $result = array("Status"=>"ok","findthispatient"=>$findpid);//,"metaarr"=>$metaarr,"findallpatient"=>$findallpatient
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchphysotherpydata))
        {
            $appid = $postdata->appid;
            
            $findappdeatils = find("first","appointment","*","where appointment_id = '".$appid."' ",array());
            $findpid = find("first","patient","*","where patient_id = '".$findappdeatils['patient_id']."' ",array());
            $findpaatientmetadata = find("all","patient_meta","*","where patient_id = '".$findappdeatils['patient_id']."' ",array());
            $metaarr = array();
            foreach($findpaatientmetadata as $k=>$v){
                $temparr = array($v['meta_key']=>$v['meta_value']);
                $metaarr = array_merge($metaarr,$temparr);
            }
            
            $result = array("Status"=>"ok","metaarr"=>$metaarr,"findpid"=>$findpid);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchprfileddata))
        {
            $patientuid = $postdata->patientid;

            $findpid = find("first","patient","*","where unique_pid = '".$patientuid."' ",array());

            // $findpaatientmetadata = find("all","patient_meta","*","where patient_id = '".$findpid['patient_id']."' ",array());
            // $metaarr = array();
            // foreach($findpaatientmetadata as $k=>$v){
            //     $temparr = array($v['meta_key']=>$v['meta_value']);
            //     $metaarr = array_merge($metaarr,$temparr);
            // }

            $result = array("Status"=>"ok","findthispatient"=>$findpid);//"metaarr"=>$metaarr
	        echo json_encode($result);
        }
        
        
        if(isset($postdata->updatepatient))
        {
            $puid = $postdata->puid;
            $findpid = find("first","patient","*","where unique_pid = '".$puid."' ",array());
            $pid = $findpid['patient_id'];
            $mobile_number = $postdata->mobile_number;
            $pmail = $postdata->email;
            $pdob = $postdata->pdob;
            $psex = $postdata->psex;
            $paddres = $postdata->paddres;
            $pdistrict = $postdata->pdistrict;
            $pcity = $postdata->pcity;
            
            
            $setvalue = "email=:email,mobile_number=:mobile_number,gender=:gender,city=:city,district=:district,address=:address,dob=:dob";
            $wherecon = "where patient_id = '".$pid."' ";
            $execon = array(
                ":email"=>$pmail,
                ":mobile_number"=>$mobile_number,
                ":gender" => $psex,
                ":city" => $pcity,
                ":district" => $pdistrict,
                ":address" => $paddres,
                ":dob" => $pdob,
                );
            $updatepatient = update("patient",$setvalue,$wherecon,$execon);
            // if($updatepatient){
            //     foreach($postdata as $key=>$val){
            //         // print_r($key);
            //         if($key != 'updatepatient' && $key != 'puid' && $key != 'mobile_number' && $key != 'email' && $key != 'patient_name'){
            //             // print_r(find("first","patient_meta","*","where meta_key = '".$key."' ",array()));
            //             if(find("first","patient_meta","*","where meta_key = '".$key."' and patient_id = '".$pid."' ",array())){
            //                 $setv = "meta_value=:meta_value";
            //                 $wherec = "where patient_id = '".$pid."' and meta_key = '".$key."' ";
            //                 $exec = array(":meta_value"=>$val);
            //                 $updatepm = update("patient_meta",$setv,$wherec,$exec);
            //             } else {
            //                 // print_r(array(":patient_id"=>$pid,":meta_key"=>$key,":meta_value"=>$val));
            //                 $savepm = save("patient_meta","patient_id,meta_key,meta_value",":patient_id,:meta_key,:meta_value",array(":patient_id"=>$pid,":meta_key"=>$key,":meta_value"=>$val));
            //             }
            //         }
            //     }
            //     // print_r($postdata);
            // }
            $result = array("Status"=>"ok","updatepatient"=>$updatepatient);//,"updatepm"=>$updatepm);
	        echo json_encode($result);
        }
    }
?>