<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->add_role))
        {
            $role_name = $postdata->role_name;
            
            $fields = 'role_name';
            $values = ':role_name';
            $exe = array(
                            ":role_name" => $role_name,
                        );
            $saverole = save('role',$fields,$values,$exe);

            $result = array("Status"=>"ok","saverole"=>$saverole);
	        echo json_encode($result);
        }

        if(isset($postdata->fetch_role))
        {   
            $findroles = find("all","role","*","where 1",array());

            $result = array("Status"=>"ok","findroles"=>$findroles);
	        echo json_encode($result);
        }

        if(isset($postdata->fetchmodulesrole))
        {
            $findmodules = find("all","module","*","where module_parent_id = '' ",array());
            $modulearray = array();
            foreach($findmodules as $mval){
                array_push($modulearray,$mval);
                $findmodulechild = find("all","module","*","where module_parent_id = '".$mval['module_id']."' ",array());
                if($findmodulechild){
                    foreach($findmodulechild as $fmc){ array_push($modulearray,$fmc); }
                }
                // print_r($findmodulechild);
            }

            // print_r($modulearray);
            $result = array("Status"=>"ok","findmodules"=>$modulearray);
	        echo json_encode($result);
        }

        if(isset($postdata->saveroleaccess))
        {
            $resmodulerarr = $postdata->resmodulerarr;
            $selectedrole = $postdata->selectedrole;

            $findroleprevious = find("all","rolemodule","*","where role_id = '".$selectedrole."' ",array());
            if($findroleprevious){
                $deletepreviousrole = delete("rolemodule","where role_id = '".$selectedrole."' ",array());
            }
            $fields = "role_id,module_id,module_slug";
            $values = ":role_id,:module_id,:module_slug";
            foreach($resmodulerarr as $key=>$val){
                $explodedarr = explode(":",$val);
                $exe = array(":role_id"=>$selectedrole,":module_id"=>$explodedarr[1],":module_slug"=>$explodedarr[0]);
                $saverolemodule = save("rolemodule",$fields,$values,$exe);
            }

            $result = array("Status"=>"ok","saverolemodule"=>$saverolemodule);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchchkrole))
        {
            $roleselected = $postdata->roleselected;
            
            $asiignroles = [];
            $findassignedrole = find("all","rolemodule","module_slug,module_id","where role_id = '$roleselected' ",array());
            foreach($findassignedrole as $k=>$v){
                $arrval = $v['module_slug'].":".$v['module_id'];
                array_push($asiignroles,$arrval);
                // array_push($asiignroles,$v['module_id']);
            }
            
            $result = array("Status"=>"ok","findassignedrole"=>$asiignroles);
	        echo json_encode($result);
        }

    }
    // $result = array("Status"=>"ok");
	// echo json_encode($result);
?>