<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

include("../init.php");
    
    
    $pid = $_POST['pid'];
    $doctor_id = $_POST['doctor_id'];
    $schdate = $_POST['schdate'];
    $starttime = $_POST['starttime'];
    $endtime = $_POST['endtime'];
    $department = $_POST['department'];
    $saveappoitment = $_POST['saveappoitment'];
    
    $findpemail = find("first","patient","*","where patient_id = '".$pid."' ",array());
    
    //for patient
    $to = $findpemail['email'];
    $name = $findpemail['patient_name'];
    $subject = "Appointment Booked Confirmation";
    $fromname = "CoreConcept";
    $message = "
                    Dear $name,
                    <br><br>
                    I am writing to confirm your appointment with CoreConcept on $schdate at $starttime to $endtime. We are excited to meet with you and look forward to discussing about your problem.
                    <br><br>
                    The details of your appointment are as follows:
                    Date: $schdate
                    Time: $starttime - $endtime
                    Location: In Clinic
                    <br><br>
                    If for any reason you need to reschedule or cancel your appointment, please login to our site prior to your scheduled appointment.
                    <br>
                    If you have any questions or concerns, please do not hesitate to contact us.
                    <br><br>
                    Thank you for choosing CoreConcept. We look forward to seeing you soon.
                    <br><br>
                    Best regards,<br>
                    CoreConcept Support Team
                ";
    require 'PHPMailerAutoload.php';
    $mail = new PHPMailer(); // create a new object
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 2; // debugging: 1 = errors and messages, 2 = messages only
    $mail->Host = "smtp.hostinger.com";
    $mail->Port = 465;
    $mail->SMTPAuth = true; // authentication enabled
    $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
    $mail->IsHTML(true);
    $mail->Username = "sendmail@tdtl.info";
    $mail->Password = "Tdtl@23081984";
    $mail->SetFrom("sendmail@tdtl.info",$fromname);
    $mail->Subject = $subject;
    $mail->Body = $message;
    $mail->AddAddress($to,$name);
    if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message has been sent";
    }
    
    
    //for doctor
    
    $finddemail = find("first","doctor","*","where doctor_id = '".$doctor_id."' ",array());
    
    $to = $finddemail['doc_email'];
    $name = $finddemail['doctor_name'];
    $subject = "Appointment Booked with ".$finddemail['doctor_name'];
    $fromname = "CoreConcept";
    $message = "
                    Dear Dr. ".$finddemail['doctor_name'].",
                    <br><br>
                    I am writing to confirm the appointment scheduled with you on $schdate at $starttime to $endtime. I am excited to meet with you and discuss your problem.
                    <br><br>
                    The details of your appointment are as follows:
                    Date: $schdate
                    Time: $starttime - $endtime
                    Location: In Clinic
                    <br><br>
                    Thank you for your time and consideration, and I look forward to seeing you soon.
                    <br><br>
                    Sincerely,<br>
                    ".$findpemail['patient_name']."
                ";
    require 'PHPMailerAutoload.php';
    $mail = new PHPMailer(); // create a new object
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 2; // debugging: 1 = errors and messages, 2 = messages only
    $mail->Host = "smtp.hostinger.com";
    $mail->Port = 465;
    $mail->SMTPAuth = true; // authentication enabled
    $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
    $mail->IsHTML(true);
    $mail->Username = "sendmail@tdtl.info";
    $mail->Password = "Tdtl@23081984";
    $mail->SetFrom("sendmail@tdtl.info",$fromname);
    $mail->Subject = $subject;
    $mail->Body = $message;
    $mail->AddAddress($to,$name);
    if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message has been sent";
    }
    
?>