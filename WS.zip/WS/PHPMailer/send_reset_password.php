<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

include("../init.php");
    
    $sendotp = $_POST['sendotp'];
    $email = $_POST['email'];
    $name = $_POST['name'];
    
    $to = $email;
    $subject = "Password Reset Request";//$_POST["subject"];
    $name = $name;//$_POST["fullname"];
    $fromname = "CoreConcept";//$_POST["fromname"];
    $message = "
                    Dear $name,
                    <br><br>
                    We have received a request to reset the password for your CoreConcept account. Please find your One-Time Password (OTP) below and enter it in the password reset form to complete the process:
                    <br><br>
                    OTP: $sendotp
                    <br><br>
                    If you did not request a password reset, please ignore this email.
                    <br><br>
                    Thank you,<br>
                    CoreConcept Support Team
                ";
    
    
    require 'PHPMailerAutoload.php';
    $mail = new PHPMailer(); // create a new object
    $mail->IsSMTP(); // enable SMTP
    $mail->SMTPDebug = 2; // debugging: 1 = errors and messages, 2 = messages only
    $mail->Host = "smtp.hostinger.com";
    $mail->Port = 465;
    $mail->SMTPAuth = true; // authentication enabled
    $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for Gmail
    $mail->IsHTML(true);
    $mail->Username = "sendmail@tdtl.info";
    $mail->Password = "Tdtl@23081984";
    $mail->SetFrom("sendmail@tdtl.info",$fromname);
    $mail->Subject = $subject;
    $mail->Body = $message;
    $mail->AddAddress($to,$name);
    
    // $filename = $_POST['filename'];
    // $fileattach = "../uploads/proposalfiles/".$filename.".pdf"; // full path
    // $mail->AddAttachment($fileattach);

    //$mail->addcc('sunnicse@gmail.com');
    if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        echo "Message has been sent";
    }
?>