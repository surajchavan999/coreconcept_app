<?php
    header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");

	include('init.php');
	if($_SERVER["REQUEST_METHOD"]=="POST")
	{
		$postdata =json_decode(file_get_contents("php://input"));

        if(isset($postdata->add_doctor))
        {
            $doctor_name = $postdata->doctor_name;
            $doctor_email = $postdata->doctor_email;
            $mobile_number = $postdata->mobile_number;
            $department = $postdata->department;
            $registation_number = $postdata->registation_number;
            $assign_color = $postdata->assign_color;
            $doctortype = $postdata->doctortype;
            $consultaionfeesfirst = $postdata->consultaionfeesfirst;
            $consultaionfeesother = $postdata->consultaionfeesother;
            
            if($doctortype == "inhouse"){
                $role = "1";
            }
            if($doctortype == "guestdoc"){
                $role = "6";
            }
         
            $findalreadydoc = find("first","doctor","*","where doc_email = '".$doctor_email."' ",array());
            if($findalreadydoc){
                $savedoctor = "Doctor Already Added";
            } else{
                $fields = 'doctor_name,doc_email,password,mobile_number,dept_id,registration_no,doctortype,consultaionfeesfirst,consultaionfeesother,doc_color,role_id,status,created_date';
                $values = ':doctor_name,:doc_email,:password,:mobile_number,:dept_id,:registration_no,:doctortype,:consultaionfeesfirst,:consultaionfeesother,:doc_color,:role_id,:status,:created_date';
                $exe = array(
                                ":doctor_name" => $doctor_name,
                                ":doc_email" => $doctor_email,
                                ":password" => "123456",
                                ":mobile_number" => $mobile_number,
                                ":dept_id" => $department,
                                ":registration_no" => $registation_number,
                                ":doctortype"=>$doctortype,
                                ":consultaionfeesfirst"=>$consultaionfeesfirst,
                                ":consultaionfeesother"=>$consultaionfeesother,
                                ":doc_color" => $assign_color,
                                ":role_id" => $role,
                                ":status" => "Y",
                                ":created_date" => date("Y-m-d H:i:s"),
                            );
                $savedoctor = save('doctor',$fields,$values,$exe);
                    
                if($savedoctor){
                    savenotification("0",$savedoctor,"","doctor","You were added to portal","You were successfully addedd to our portal"); 
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL,"https://tdtl.info/coreconcept/ws/PHPMailer/send_doctor_add.php");
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_POSTFIELDS,"savedoctor=$savedoctor");
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $server_output = curl_exec($ch);
                    curl_close ($ch);
                }
            }

            $result = array("Status"=>"ok","savedoctor"=>$savedoctor);
	        echo json_encode($result);
        }

        if(isset($postdata->editdoctor))
        {
            $doc_email = $postdata->doc_email;
            $editdepartment = $postdata->editdepartment;
            $editdoctortype = $postdata->editdoctortype;
            $editconsultaionfeesfirst = $postdata->editconsultaionfeesfirst;
            $editconsultaionfeesother = $postdata->editconsultaionfeesother;
            
            $setvalue = "dept_id=:dept_id,doctortype=:doctortype,consultaionfeesfirst=:consultaionfeesfirst,consultaionfeesother=:consultaionfeesother";
            $wherecon = "where doc_email = '".$doc_email."' ";
            $execon = array(
                ":dept_id"=>$editdepartment,
                ":doctortype"=>$editdoctortype,
                ":consultaionfeesfirst" =>$editconsultaionfeesfirst,
                ":consultaionfeesother"=>$editconsultaionfeesother,
                );
            $updatedoctor = update("doctor",$setvalue,$wherecon,$execon);
            
            $result = array("Status"=>"ok","updatedoctor"=>$updatedoctor);
	        echo json_encode($result);
        }
        
        if(isset($postdata->fetchdoctor))
        {
            // $finddoctor = find("all","doctor inner join department on doctor.dept_id=department.dept_id","*","where doctor.status = 'Y' ",array());
            $finddoctor = find("all","doctor inner join department on doctor.dept_id=department.dept_id","*","where 1 ",array());

            $result = array("Status"=>"ok","finddoctor"=>$finddoctor);
	        echo json_encode($result);
        }

        if(isset($postdata->changestatusdr))
        {
            $docid = $postdata->docid;
            $status = $postdata->status;
            
            $setvalue = "status=:status";
            $wherecon = "where doctor_id = '".$docid."' ";
            $exe = array(":status"=>$status);
            $updatedrstatus = update("doctor",$setvalue,$wherecon,$exe);
            
            $result = array("Status"=>"ok","updatedrstatus"=>$updatedrstatus);
	        echo json_encode($result);
        }
        
    }
    // $result = array("Status"=>"ok");
	// echo json_encode($result);
?>